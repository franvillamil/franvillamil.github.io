## Readme replication files

#### Manuscript "The double logic of internal purges: New evidence from Francoist Spain"

* dataset.csv: dataset used in the manuscript
* analyses.R: replicates the analyses in the main text, including graphs and tables.
* appendix.R: replicates the analyses in the appendix, including graphs.
* descriptives.R: runs the descriptive summaries, including the plot of purges over time by province in the main text, and the table on teachers' data included in the appendix

*Note:* Any of the three R scripts can be run independently of each other. The working directory should be the folder "replication" found in the zip file. If it is not, every R script prompts a box to choose any file in that folder. All the graphs and tables are saved to the same folder.
