# Working directory
if(!grepl("replication$", getwd())){
  print("Choose any file in the replication folder (e.g. analyses.R)")
  dir = file.choose()
  setwd(gsub("\\w*\\..*", "", dir))
}

# Options
options(stringsAsFactors = FALSE)

# Load packages, or install if not available
pkg_needed = c("forcats", "reshape2", "MASS", "ggplot2",
  "stringr", "stargazer", "xtable", "MatchIt", "cem")
if(!all(pkg_needed %in% rownames(installed.packages()))){
  install.packages(pkg_needed[!pkg_needed %in% rownames(installed.packages())])
  lapply(pkg_needed, require, character.only = TRUE)
} else {lapply(pkg_needed, require, character.only = TRUE)}


# Source function code
source("func_analyses.R")

# Load data
data = read.csv("dataset.csv")

### --------------------------------------------
### Main analyses

# Create DiD data structure (with left and right)
years = c("1936", "1977", "1979", "1982", "1986", "1989", "1993",
  "1996", "2000", "2004", "2008", "2011", "2015", "2016")
did = reshape(data,
  varying = names(data)[grepl("izq\\d{4}", names(data))],
  sep = "",
  direction = "long",
  idvar = "muni_code",
  timevar = "year",
  times = years,
  new.row.names = 1:(nrow(data)*length(years)) )
did = merge(did, data[,c("muni_code", "izq1936", "compet1936")])

## Defining models

# Model 1: Base
mdid1 = lm(izq ~ factor(year) * repbin +
  change4070 + lpop70 + cnt_bin + ugt_bin + izq1936 + compet1936 + elev_sd +
  factor(prov), data = did)
# Model 2: Including interaction
mdid2 = lm(izq ~ factor(year) * repbin * top_pa_nb_bin10 +
  change4070 + lpop70 + cnt_bin + ugt_bin + izq1936 + compet1936 + elev_sd +
  factor(prov), data = did)
# Model 3: Robustness 1: continuous violence measure (top_pa_nb10_bin * lnrepr)
mdid3 = lm(izq ~ factor(year) * lnrepr * top_pa_nb_bin10 +
  change4070 + lpop70 + cnt_bin + ugt_bin + izq1936 + compet1936 + elev_sd +
  factor(prov), data = did)
# Model 4: Robustness 2: excluding cities
mdid4 = lm(izq ~ factor(year) * repbin * top_pa_nb_bin10 +
  change4070 + lpop70 + cnt_bin + ugt_bin + izq1936 + compet1936 + elev_sd +
  factor(prov), data = subset(did, exp(lpop70) < 10000))

## Plot estimates for main model (2)

# Create df for simulation
extvars1 = data.frame(change4070 = 1, lpop70 = 7,
  cnt_bin = 1, ugt_bin = 1, compet1936 = 0.7, izq1936 = 0.43, elev_sd = 100)
# Run simulations
sim = did_sim_3i(model = mdid2, prov_FE = TRUE,
  osv = c(0,1), int = c(0,1), osv_name = "repbin", int_name = "top_pa_nb_bin10",
  other_vars = extvars1, simdraws = 1000)
# Create estimates
did_est = did_estimates(sim,
  int_values = c("No underground opposition activity during Francoism (local or within 10km)",
    "Underground opposition activity during Francoism (local or within 10km)"))

# Plot
jpeg("did_model1.jpeg", height = 1600, width = 3200, res = 400)
  ggplot(did_est, aes(x = year, y = mean, group = int, color = int)) +
    geom_point() +
    geom_errorbar(aes(ymin = lower, ymax = upper), width = 0.07) +
    geom_line(aes(group=int)) +
    geom_hline(yintercept = 0, linetype = "dotted") +
    theme_bw() +
    scale_y_continuous(limits = c(min(did_est$lower), 0.13)) +
    labs(x = "",
      y = "Increase in leftist vote due to\nwartime repression, relative to 1936 share") +
    theme_classic() +
    theme(panel.background = element_blank(),
          legend.position = c(0, 1.03), legend.justification = c(0,1),
          legend.title = element_blank(),
          legend.background = element_blank(),
          panel.grid = element_blank(),
          axis.ticks.x = element_blank(),
          panel.border = element_blank(),
          strip.text = element_text(size = 12),
          plot.caption = element_text(size = 9, hjust = 0, margin = margin(t = 15)),
          strip.background = element_blank()) +
    scale_color_manual(values=c("#0e80d8", "#910a0a"))
dev.off()

## Coefficient plots

# Create coefficients df
coef = rbind(
  to_coef_df(mdid1, "repbin", "top_pa_nb_bin10", "Model~1"),
  to_coef_df(mdid2, "repbin", "top_pa_nb_bin10", "Model~2"),
  to_coef_df(mdid3, "lnrepr", "top_pa_nb_bin10", "Model~3"),
  to_coef_df(mdid4, "repbin", "top_pa_nb_bin10", "Model~4"))
coef$var = fct_relevel(coef$var, levels(coef$var)[order(levels(coef$var), decreasing=T)])
coef$spec = "NULL[No~interaction]"
coef$spec[grepl("2", coef$model)] = "NULL[Main~model]"
coef$spec[grepl("3", coef$model)] = "NULL[Continuous~violence~variable]"
coef$spec[grepl("4", coef$model)] = "NULL[Only~small~towns]"

# Plotting
jpeg("coef_main.jpeg", width = 3200, height = 3200, res = 400)
ggplot(coef, aes(x = b, y = var)) +
  geom_vline(xintercept = 0, lty = "dotted", color = gray(0.5)) +
  geom_point() +
  geom_errorbarh(aes(xmin = lwr, xmax = upr), height = 0) +
  theme_classic() +
  scale_x_continuous(breaks = c(-0.1, 0, 0.1)) +
  theme(panel.background = element_blank(),
          panel.grid = element_blank(),
          panel.grid.major.y = element_line(size = 0.25, color = gray(0.95)),
          axis.ticks.y = element_blank(),
          panel.border = element_blank(),
          strip.text = element_text(size = 12),
          plot.caption = element_text(size = 9, hjust = 0, margin = margin(t = 15)),
          strip.background = element_blank()) +
  labs(x = "Coefficient estimate and 95% CI", y=NULL,
      title=NULL, subtitle=NULL) +
  facet_wrap(~model+spec, ncol = 4, labeller = label_parsed)
dev.off()

## Full tables

years = as.character(c(1977, 1979, 1982, 1986, 1989,
  1993, 1996, 2000, 2004, 2008, 2011, 2015, 2016))

mdid3_mod = mdid3
names(mdid3_mod$coefficients) = gsub("lnrepr", "repbin",
  names(mdid3_mod$coefficients))

stargazer(mdid1, mdid2, mdid3_mod, mdid4, type = "text",
  title = "Table A2: Wartime victimization and leftist vote increase",
  omit = "prov", intercept.bottom = FALSE,
  covariate.labels = c("(Intercept)",
    paste0("Election ", years), "Wartime victimization",
    "Networks (TOP activity)", "Change pop 1940-70",
    "Log. Population 1970", "Unions (CNT)", "Unions (UGT)",
    "Leftist vote 1936", "Elec. competition 1936",
    "Terrain ruggedness", paste0(years, " x Victimization"),
    paste0(years, " x TOP"), "Victimization x TOP",
    paste0(years, " x Vict. x TOP")),
  dep.var.labels = c(""), dep.var.labels.include = FALSE,
  star.char = c("+", "*", "**", "***"),
  star.cutoffs = c(0.1, 0.05, 0.01, 0.001),
  omit.stat = c("f", "ser")
)

### --------------------------------------------
### 2. Alternative explanations

## Network presence as DV

# Models
org1nofe = glm(top_pa_bin ~ repbin + izq1936 + change4060 +
  lpop60 + sindic_bin + compet1936 + elev_sd,
  data = data, family = "binomial")
org1 = glm(top_pa_bin ~ repbin + izq1936 + change4060 +
  lpop60 + sindic_bin + compet1936 + elev_sd + factor(prov),
  data = data, family = "binomial")
org2nofe = glm(top_pa_bin ~ repbin * izq1936 + change4060 +
  lpop60 + sindic_bin + compet1936 + elev_sd,
  data = data, family = "binomial")
org2 = glm(top_pa_bin ~ repbin * izq1936 + change4060 +
  lpop60 + sindic_bin + compet1936 + elev_sd + factor(prov),
  data = data, family = "binomial")

# Preparing coefficient dataframe
coef_org1 = as.data.frame(summary(org1nofe)$coefficients)[, c("Estimate", "Std. Error")]
coef_org2 = as.data.frame(summary(org1)$coefficients)[, c("Estimate", "Std. Error")]
coef_org3 = as.data.frame(summary(org2nofe)$coefficients)[, c("Estimate", "Std. Error")]
coef_org4 = as.data.frame(summary(org2)$coefficients)[, c("Estimate", "Std. Error")]
coef_org1$model = "Model~5\n"
coef_org2$model = "Model~6\n"
coef_org3$model = "Model~7\n"
coef_org4$model = "Model~8\n"
coef_org1$spec = ""
coef_org2$spec = "NULL[Province~FE]"
coef_org3$spec = ""
coef_org4$spec = "NULL[Province~FE]"
coef_org1$var = row.names(coef_org1)
coef_org2$var = row.names(coef_org2)
coef_org3$var = row.names(coef_org3)
coef_org4$var = row.names(coef_org4)
coef_org = rbind(coef_org1, coef_org2, coef_org3, coef_org4)
coef_org = subset(coef_org, !grepl("factor\\(prov\\)|Intercept", var))
rownames(coef_org) = 1:nrow(coef_org)
names(coef_org)[1:2] = c("b", "se")
coef_org$upr = coef_org$b + (1.96 * coef_org$se)
coef_org$lwr = coef_org$b - (1.96 * coef_org$se)
# Variable names
coef_org$var[coef_org$var == "change4060"] = "Pop. change 1940-1960"
coef_org$var[coef_org$var == "compet1936"] = "Elec. competition 1936"
coef_org$var[coef_org$var == "elev_sd"] = "Terrain ruggedness"
coef_org$var[coef_org$var == "izq1936"] = "Leftist support 1936"
coef_org$var[coef_org$var == "lpop60"] = "Log. Pop. 1960"
coef_org$var[coef_org$var == "repbin"] = "CW Victimization"
coef_org$var[coef_org$var == "repbin:izq1936"] = "Victimization x Left 1936"
coef_org$var[coef_org$var == "sindic_bin"] = "Pre-war trade unions"
coef_org$var = fct_relevel(coef_org$var,
  c("Terrain ruggedness", "Pop. change 1940-1960", "Log. Pop. 1960",
  "Pre-war trade unions", "Elec. competition 1936", "Victimization x Left 1936",
  "CW Victimization", "Leftist support 1936"))

# Plotting
jpeg("coef_logit_networks.jpeg", width = 3200, height = 1600, res = 400)
ggplot(coef_org, aes(x = b, y = var)) +
  geom_vline(xintercept = 0, lty = "dotted", color = gray(0.5)) +
  geom_point() +
  geom_errorbarh(aes(xmin = lwr, xmax = upr), height = 0) +
  theme_classic() +
  scale_x_continuous(breaks = c(-2, 0, 2)) +
  theme(panel.background = element_blank(),
          panel.grid = element_blank(),
          panel.grid.major.y = element_line(size = 0.25, color = gray(0.95)),
          axis.ticks.y = element_blank(),
          panel.border = element_blank(),
          strip.text = element_text(size = 12),
          plot.caption = element_text(size = 9, hjust = 0, margin = margin(t = 15)),
          strip.background = element_blank()) +
  labs(x = "Coefficient estimate and 95% CI", y=NULL,
      title=NULL, subtitle=NULL) +
  facet_wrap(~model+spec, ncol = 4, labeller = label_parsed)
dev.off()

## Organizational persistence (prewar trade unions)

# Models
mdid_orgs = lm(izq ~ factor(year) * repbin * sindic_bin +
  change4070 + lpop70 + top_pa_nb_bin10 + izq1936 + compet1936 + elev_sd +
  factor(prov), data = did)
mdid_orgs2 = lm(izq ~ factor(year) * lnrepr * sindic_bin +
  change4070 + lpop70 + top_pa_nb_bin10 + izq1936 + compet1936 + elev_sd +
  factor(prov), data = did)
mdid_orgs3 = lm(izq ~ factor(year) * repbin * sindic_bin +
  change4070 + lpop70 + top_pa_nb_bin10 + izq1936 + compet1936 + elev_sd +
  factor(prov), data = subset(did, exp(lpop70) < 10000))

# Create coefficient df to plot
coef_prewarorgs = rbind(
  to_coef_df(mdid_orgs, "repbin", "sindic_bin", "Model~9"),
  to_coef_df(mdid_orgs2, "lnrepr", "sindic_bin", "Model~10"),
  to_coef_df(mdid_orgs3, "repbin", "sindic_bin", "Model~11"))
levels(coef_prewarorgs$var) = gsub("Networks", "Prewar Unions", levels(coef_prewarorgs$var))
coef_prewarorgs$model = fct_relevel(coef_prewarorgs$model, c("Model~9", "Model~10", "Model~11"))
coef_prewarorgs$spec = "NULL[Main~model]"
coef_prewarorgs$spec[grepl("10", coef_prewarorgs$model)] = "NULL[Continuous~violence~variable]"
coef_prewarorgs$spec[grepl("11", coef_prewarorgs$model)] = "NULL[Only~small~towns]"

# Plotting
jpeg("coef_org_persistence.jpeg", height = 3200, width = 3200, res = 400)
ggplot(coef_prewarorgs, aes(x = b, y = var)) +
  geom_vline(xintercept = 0, lty = "dotted", color = gray(0.5)) +
  geom_point() +
  geom_errorbarh(aes(xmin = lwr, xmax = upr), height = 0) +
  theme_classic() +
  scale_x_continuous(breaks = c(-0.1, 0, 0.1)) +
  theme(panel.background = element_blank(),
          panel.grid = element_blank(),
          panel.grid.major.y = element_line(size = 0.25, color = gray(0.95)),
          axis.ticks.y = element_blank(),
          panel.border = element_blank(),
          strip.text = element_text(size = 12),
          plot.caption = element_text(size = 9, hjust = 0, margin = margin(t = 15)),
          strip.background = element_blank()) +
  labs(x = "Coefficient estimate and 95% CI", y=NULL,
      title=NULL, subtitle=NULL) +
  facet_wrap(~model+spec, ncol = 3, labeller = label_parsed)
dev.off()

# For stargazer
mdid_orgs2_mod = mdid_orgs2
names(mdid_orgs2_mod$coefficients) = gsub("lnrepr", "repbin",
  names(mdid_orgs2_mod$coefficients))

stargazer(mdid_orgs, mdid_orgs2_mod, mdid_orgs3, type = "text",
  title = "Table A3: Wartime victimization and leftist vote increase",
  omit = "prov", intercept.bottom = FALSE,
  covariate.labels = c("(Intercept)",
    paste0("Election ", years), "Wartime victimization",
    "Trade Unions", "Change pop 1940-70",
    "Log. Population 1970", "Networks (TOP activity)",
    "Leftist vote 1936", "Elec. competition 1936",
    "Terrain ruggedness", paste0(years, " x Victimization"),
    paste0(years, " x Unions"), "Victimization x Unions",
    paste0(years, " x Vict. x Unions")),
  dep.var.labels = c(""), dep.var.labels.include = FALSE,
  star.char = c("+", "*", "**", "***"),
  star.cutoffs = c(0.1, 0.05, 0.01, 0.001),
  omit.stat = c("f", "ser")
)

# Create df for simulation
extvars2 = data.frame(change4070 = 1, lpop70 = 7, top_pa_nb_bin10 = 1,
  compet1936 = 0.7, izq1936 = 0.43, elev_sd = 100)
# Run simulations
sim_orgs = did_sim_3i(model = mdid_orgs, prov_FE = TRUE,
  osv = c(0,1), int = c(0,1), osv_name = "repbin", int_name = "sindic_bin",
  other_vars = extvars2, simdraws = 1000)
# Create estimates
did_est_orgs = did_estimates(sim_orgs,
  int_values = c("No trade unions before the war",
    "Trade unions before the war"))

# Plot
jpeg("did_model_orgs.jpeg", height = 1600, width = 3200, res = 400)
  ggplot(did_est_orgs, aes(x = year, y = mean, group = int, color = int)) +
    geom_point() +
    geom_errorbar(aes(ymin = lower, ymax = upper), width = 0.07) +
    geom_line(aes(group=int)) +
    geom_hline(yintercept = 0, linetype = "dotted") +
    theme_bw() +
    scale_y_continuous(limits = c(min(did_est_orgs$lower), 0.13)) +
    labs(x = "",
      y = "Increase in leftist vote due to\nwartime repression, relative to 1936 share") +
    theme_classic() +
    theme(panel.background = element_blank(),
          legend.position = c(0, 1.03), legend.justification = c(0,1),
          legend.title = element_blank(),
          legend.background = element_blank(),
          panel.grid = element_blank(),
          axis.ticks.x = element_blank(),
          panel.border = element_blank(),
          strip.text = element_text(size = 12),
          plot.caption = element_text(size = 9, hjust = 0, margin = margin(t = 15)),
          strip.background = element_blank()) +
    scale_color_manual(values=c("#0e80d8", "#910a0a"))
dev.off()

### --------------------------------------------
### 3. Appendix

## Spatial analyses

# Models with spatial lags of violence
mdid_nb = lm(izq ~ factor(year) * repbin * top_pa_nb_bin10 + repbin_nb +
  change4070 + lpop70 + cnt_bin + ugt_bin + izq1936 + compet1936 + elev_sd +
  factor(prov), data = did)
mdid_nb5 = lm(izq ~ factor(year) * repbin * top_pa_nb_bin10 + repbin_nb5 +
  change4070 + lpop70 + cnt_bin + ugt_bin + izq1936 + compet1936 + elev_sd +
  factor(prov), data = did)
mdid_nb10 = lm(izq ~ factor(year) * repbin * top_pa_nb_bin10 + repbin_nb10 +
  change4070 + lpop70 + cnt_bin + ugt_bin + izq1936 + compet1936 + elev_sd +
  factor(prov), data = did)

# Create coefficient df to plot
coef_spatial = rbind(
  to_coef_df(mdid_nb, "repbin", "top_pa_nb_bin10", "Model~A4"),
  to_coef_df(mdid_nb5, "repbin", "top_pa_nb_bin10", "Model~A5"),
  to_coef_df(mdid_nb10, "repbin", "top_pa_nb_bin10", "Model~A6"))
# coefdf$var = fct_relevel(coefdf$var, levels(coefdf$var)[order(levels(coefdf$var), decreasing=T)])
coef_spatial$model = fct_relevel(coef_spatial$model, c("Model~A4", "Model~A5", "Model~A6"))
coef_spatial$spec = "NULL[Spatial~lag~contiguity]"
coef_spatial$spec[grepl("5", coef_spatial$model)] = "NULL[Spatial~lag~within~`5km`]"
coef_spatial$spec[grepl("6", coef_spatial$model)] = "NULL[Spatial~lag~within~`10km`]"

levels(coef_spatial$var) = gsub("Violence_nb(|5|10)", "Violence (spatial lag)",
  levels(coef_spatial$var))

# Plotting
jpeg("app_coef_spatial.jpeg", height = 3200, width = 3200, res = 400)
ggplot(coef_spatial, aes(x = b, y = var)) +
  geom_vline(xintercept = 0, lty = "dotted", color = gray(0.5)) +
  geom_point() +
  geom_errorbarh(aes(xmin = lwr, xmax = upr), height = 0) +
  theme_classic() +
  scale_x_continuous(breaks = c(-0.1, 0, 0.1)) +
  theme(panel.background = element_blank(),
          panel.grid = element_blank(),
          panel.grid.major.y = element_line(size = 0.25, color = gray(0.95)),
          axis.ticks.y = element_blank(),
          panel.border = element_blank(),
          strip.text = element_text(size = 12),
          plot.caption = element_text(size = 9, hjust = 0, margin = margin(t = 15)),
          strip.background = element_blank()) +
  labs(x = "Coefficient estimate and 95% CI", y=NULL,
      title=NULL, subtitle=NULL) +
  facet_wrap(~model+spec, ncol = 3, labeller = label_parsed)
dev.off()

## Excluding Euskadi

# Models
mdid_noeuk1 = lm(izq ~ factor(year) * repbin * top_pa_nb_bin10 +
  change4070 + lpop70 + cnt_bin + ugt_bin + izq1936 + compet1936 + elev_sd +
  factor(prov), data = subset(did, !euk))
mdid_noeuk2 = lm(izq ~ factor(year) * lnrepr * top_pa_nb_bin10 +
  change4070 + lpop70 + cnt_bin + ugt_bin + izq1936 + compet1936 + elev_sd +
  factor(prov), data = subset(did, !euk))
mdid_noeuk3 = lm(izq ~ factor(year) * repbin * top_pa_nb_bin10 +
  change4070 + lpop70 + cnt_bin + ugt_bin + izq1936 + compet1936 + elev_sd +
  factor(prov), data = subset(did, exp(lpop70) < 10000 & !euk))

coef_noeuk = rbind(
  to_coef_df(mdid_noeuk1, "repbin", "top_pa_nb_bin10", "Model~A7"),
  to_coef_df(mdid_noeuk2, "lnrepr", "top_pa_nb_bin10", "Model~A8"),
  to_coef_df(mdid_noeuk3, "repbin", "top_pa_nb_bin10", "Model~A9"))

coef_noeuk$spec = "NULL[Main~model]"
coef_noeuk$spec[grepl("8", coef_noeuk$model)] = "NULL[Continuous~violence~variable]"
coef_noeuk$spec[grepl("9", coef_noeuk$model)] = "NULL[Only~small~towns]"

jpeg("app_coef_no_euskadi.jpeg", height = 3200, width = 3200, res = 400)
ggplot(coef_noeuk, aes(x = b, y = var)) +
  geom_vline(xintercept = 0, lty = "dotted", color = gray(0.5)) +
  geom_point() +
  geom_errorbarh(aes(xmin = lwr, xmax = upr), height = 0) +
  theme_classic() +
  scale_x_continuous(breaks = c(-0.1, 0, 0.1)) +
  theme(panel.background = element_blank(),
          panel.grid = element_blank(),
          panel.grid.major.y = element_line(size = 0.25, color = gray(0.95)),
          axis.ticks.y = element_blank(),
          panel.border = element_blank(),
          strip.text = element_text(size = 12),
          plot.caption = element_text(size = 9, hjust = 0, margin = margin(t = 15)),
          strip.background = element_blank()) +
  labs(x = "Coefficient estimate and 95% CI", y=NULL,
      title=NULL, subtitle=NULL) +
  facet_wrap(~model+spec, ncol = 3, labeller = label_parsed)
dev.off()

## Different specifications for TOP

# Models
mdid_difftop1 = lm(izq ~ factor(year) * repbin * top_pa_nb_bin5 +
  change4070 + lpop70 + cnt_bin + ugt_bin + izq1936 + compet1936 + elev_sd +
  factor(prov), data = did)
mdid_difftop2 = lm(izq ~ factor(year) * repbin * top_pa_nb_bin20 +
  change4070 + lpop70 + cnt_bin + ugt_bin + izq1936 + compet1936 + elev_sd +
  factor(prov), data = did)
mdid_difftop3 = lm(izq ~ factor(year) * repbin * top_pa_bin +
  change4070 + lpop70 + cnt_bin + ugt_bin + izq1936 + compet1936 + elev_sd +
  factor(prov), data = did)

coef_difftop = rbind(
  to_coef_df(mdid_difftop1, "repbin", "top_pa_nb_bin5", "Model~A10"),
  to_coef_df(mdid_difftop2, "repbin", "top_pa_nb_bin20", "Model~A11"),
  to_coef_df(mdid_difftop3, "repbin", "top_pa_bin", "Model~A12"))

coef_difftop$spec = "NULL[Buffer~`5km`]"
coef_difftop$spec[grepl("11", coef_difftop$model)] = "NULL[Buffer~`20km`]"
coef_difftop$spec[grepl("12", coef_difftop$model)] = "NULL[Only~municipalities~with~activity]"

jpeg("app_coef_buffer_top.jpeg", height = 3200, width = 3200, res = 400)
ggplot(coef_difftop, aes(x = b, y = var)) +
  geom_vline(xintercept = 0, lty = "dotted", color = gray(0.5)) +
  geom_point() +
  geom_errorbarh(aes(xmin = lwr, xmax = upr), height = 0) +
  theme_classic() +
  scale_x_continuous(breaks = c(-0.1, 0, 0.1)) +
  theme(panel.background = element_blank(),
          panel.grid = element_blank(),
          panel.grid.major.y = element_line(size = 0.25, color = gray(0.95)),
          axis.ticks.y = element_blank(),
          panel.border = element_blank(),
          strip.text = element_text(size = 12),
          plot.caption = element_text(size = 9, hjust = 0, margin = margin(t = 15)),
          strip.background = element_blank()) +
  labs(x = "Coefficient estimate and 95% CI", y=NULL,
      title=NULL, subtitle=NULL) +
  facet_wrap(~model+spec, ncol = 3, labeller = label_parsed)
dev.off()

## Accounting for leftist victimization

mdid_leftvio1 = lm(izq ~ factor(year) * repbin * top_pa_nb_bin10 + leftvio +
  change4070 + lpop70 + cnt_bin + ugt_bin + izq1936 + compet1936 + elev_sd +
  factor(prov), data = subset(did, !is.na(leftvio)))
mdid_leftvio2 = lm(izq ~ factor(year) * repbin * top_pa_nb_bin10 + lnreprleft +
  change4070 + lpop70 + cnt_bin + ugt_bin + izq1936 + compet1936 + elev_sd +
  factor(prov), data = subset(did, !is.na(leftvio)))
mdid_leftvio3 = lm(izq ~ factor(year) * leftvio * top_pa_nb_bin10 + repbin +
  change4070 + lpop70 + cnt_bin + ugt_bin + izq1936 + compet1936 + elev_sd +
  factor(prov), data = subset(did, !is.na(leftvio)))

coef_leftvio = rbind(
  to_coef_df(mdid_leftvio1, "repbin", "top_pa_nb_bin10", "Model~A13"),
  to_coef_df(mdid_leftvio2, "repbin", "top_pa_nb_bin10", "Model~A14"),
  to_coef_df(mdid_leftvio3, "leftvio", "top_pa_nb_bin10", "Model~A15"))

coef_leftvio$spec = "NULL[Leftist~violence~incidence~as~control]"
coef_leftvio$spec[grepl("14", coef_leftvio$model)] = "NULL[Leftist~violence~intensity~as~control]"
coef_leftvio$spec[grepl("15", coef_leftvio$model)] = "NULL[Leftist~violence~`in`~main~interaction]"

jpeg("app_coef_leftvio.jpeg", height = 3200, width = 3200, res = 400)
ggplot(coef_leftvio, aes(x = b, y = var)) +
  geom_vline(xintercept = 0, lty = "dotted", color = gray(0.5)) +
  geom_point() +
  geom_errorbarh(aes(xmin = lwr, xmax = upr), height = 0) +
  theme_classic() +
  scale_x_continuous(breaks = c(-0.1, 0, 0.1)) +
  theme(panel.background = element_blank(),
          panel.grid = element_blank(),
          panel.grid.major.y = element_line(size = 0.25, color = gray(0.95)),
          axis.ticks.y = element_blank(),
          panel.border = element_blank(),
          strip.text = element_text(size = 12),
          plot.caption = element_text(size = 9, hjust = 0, margin = margin(t = 15)),
          strip.background = element_blank()) +
  labs(x = "Coefficient estimate and 95% CI", y=NULL,
      title=NULL, subtitle=NULL) +
  facet_wrap(~model+spec, ncol = 3, labeller = label_parsed)
dev.off()


## Using matching on base model without interactions

# Match data (coarsened exact matching & nearest neighbor)
data_prem = na.omit(subset(data, select = c("muni_code", "prov_code",
  "repbin", "izq1936", "compet1936", "lpop30", "sindic_bin", "elev_sd")))
m_cem = matchit(repbin ~ izq1936 + compet1936 + lpop30 + sindic_bin + elev_sd,
  method = "cem", data = data_prem)
m_nn = matchit(repbin ~ izq1936 + compet1936 + lpop30 + sindic_bin + elev_sd,
  method = "nearest", replace = TRUE, data = data_prem)
datam_cem = match.data(m_cem)
datam_nn = match.data(m_nn)

# Balance tables
covs_matching = c("Distance", "Leftist support 1936", "Competition 1936",
  "Log Population 1930", "Trade unions", "Ruggedness")
stats = c("Means Treated", "Means Control", "Mean Diff")
balance_tables = list(
  summary(m_nn)$sum.all[stats],
  summary(m_nn)$sum.matched[stats],
  summary(m_cem)$sum.matched[stats])
rownames(balance_tables[[1]]) = covs_matching
rownames(balance_tables[[2]]) = covs_matching
rownames(balance_tables[[3]]) = covs_matching
balance_tables[[2]] = cbind(balance_tables[[2]],
  Improvement = summary(m_nn)$reduction[,1])
balance_tables[[3]] = cbind(balance_tables[[3]],
  Improvement = summary(m_cem)$reduction[,1])

# Add t-test and p-value
get_t_test = function(depvar, data){
  f = paste0(depvar, " ~ repbin")
  model = lm(as.formula(f), data = data, weights = weights)
  coef = summary(model)$coefficients
  coef = coef[rownames(coef)=="repbin", 3:4]
  output = data.frame(ttest = coef[1], pvalue = coef[2])
  rownames(output) = depvar
  return(output)
}

balance_tables[[2]] = cbind(balance_tables[[2]],
  rbind(get_t_test("distance", datam_nn),
    get_t_test("izq1936", datam_nn),
    get_t_test("compet1936", datam_nn),
    get_t_test("lpop30", datam_nn),
    get_t_test("sindic_bin", datam_nn),
    get_t_test("elev_sd", datam_nn))
  )

balance_tables[[3]] = cbind(balance_tables[[3]],
  rbind(get_t_test("distance", datam_cem),
    get_t_test("izq1936", datam_cem),
    get_t_test("compet1936", datam_cem),
    get_t_test("lpop30", datam_cem),
    get_t_test("sindic_bin", datam_cem),
    get_t_test("elev_sd", datam_cem))
  )

balance_tables[[1]]
balance_tables[[2]]
balance_tables[[3]]

# Create matched & base dataframes
did_matched_cem = merge(datam_cem, data[, c("muni_code", "prov",
  "izq1977", "izq1979", "izq1982", "izq1986", "izq1989",
  "izq1993", "izq1996", "izq2000", "izq2004", "izq2008",
  "izq2011", "izq2015", "izq2016")])
did_matched_nn = merge(datam_nn, data[, c("muni_code", "prov",
  "izq1977", "izq1979", "izq1982", "izq1986", "izq1989",
  "izq1993", "izq1996", "izq2000", "izq2004", "izq2008",
  "izq2011", "izq2015", "izq2016")])
did_base = subset(data,
  select = c("prov", "muni_code",
  "repbin", "izq1936", "compet1936", "lpop30", "sindic_bin", "elev_sd",
  "izq1977", "izq1979", "izq1982", "izq1986", "izq1989", "izq1993", "izq1996", "izq2000",
  "izq2004", "izq2008", "izq2011", "izq2015", "izq2016"))

# Long-form dataframe for DiD
years = c("1936", "1977", "1979", "1982", "1986", "1989", "1993",
  "1996", "2000", "2004", "2008", "2011", "2015", "2016")
years2 = c("1977", "1979", "1982", "1986", "1989", "1993",
  "1996", "2000", "2004", "2008", "2011", "2015", "2016")
# Base
did_base = reshape(did_base,
  varying = names(did_base)[grepl("izq\\d{4}", names(did_base))],
  sep = "",
  direction = "long",
  idvar = "muni_code",
  timevar = "year",
  times = years,
  new.row.names = 1:(nrow(did_base)*length(years)) )
did_base$postwar = ifelse(as.integer(did_base$year)>1940, 1, 0)
did_base = merge(did_base, data[,c("muni_code", "izq1936")], all.x = TRUE)
# Matched: CEM
did_matched_cem = reshape(did_matched_cem,
  varying = names(did_matched_cem)[grepl("izq\\d{4}", names(did_matched_cem))],
  sep = "",
  direction = "long",
  idvar = "muni_code",
  timevar = "year",
  times = years,
  new.row.names = 1:(nrow(did_matched_cem)*length(years)) )
did_matched_cem$postwar = ifelse(as.integer(did_matched_cem$year)>1940, 1, 0)
did_matched_cem = merge(did_matched_cem, data[,c("muni_code", "izq1936")], all.x = TRUE)
# Matched: NN
did_matched_nn = reshape(did_matched_nn,
  varying = names(did_matched_nn)[grepl("izq\\d{4}", names(did_matched_nn))],
  sep = "",
  direction = "long",
  idvar = "muni_code",
  timevar = "year",
  times = years,
  new.row.names = 1:(nrow(did_matched_nn)*length(years)) )
did_matched_nn$postwar = ifelse(as.integer(did_matched_nn$year)>1940, 1, 0)
did_matched_nn = merge(did_matched_nn, data[,c("muni_code", "izq1936")], all.x = TRUE)

# Matched data analyses
base_model = lm(izq ~ factor(year) * repbin +
  lpop30 + sindic_bin + izq1936 + compet1936 + elev_sd +
  factor(prov), data = did_base)
base_model_cem = lm(izq ~ factor(year) * repbin +
  lpop30 + sindic_bin + izq1936 + compet1936 + elev_sd +
  factor(prov), data = did_matched_cem, weights = weights) # no UGT in CEM matched data
base_model_nn = lm(izq ~ factor(year) * repbin +
  lpop30 + sindic_bin + izq1936 + compet1936 + elev_sd +
  factor(prov), data = did_matched_nn, weights = weights)

coef_matching = rbind(
  to_coef_df(base_model, "repbin", "top_pa_nb_bin10", "Model~A1"),
  to_coef_df(base_model_nn, "repbin", "top_pa_nb_bin10", "Model~A2"),
  to_coef_df(base_model_cem, "repbin", "top_pa_nb_bin10", "Model~A3"))

coef_matching$spec = "NULL[Full~sample]"
coef_matching$spec[grepl("2", coef_matching$model)] = "NULL[Nearest~Neighbor~Matching]"
coef_matching$spec[grepl("3", coef_matching$model)] = "NULL[Coarsened~Exact~Matching]"

jpeg("app_coef_matching.jpeg", height = 1600, width = 3200, res = 400)
ggplot(coef_matching, aes(x = b, y = var)) +
  geom_vline(xintercept = 0, lty = "dotted", color = gray(0.5)) +
  geom_point() +
  geom_errorbarh(aes(xmin = lwr, xmax = upr), height = 0) +
  theme_classic() +
  scale_x_continuous(breaks = c(-0.1, 0, 0.1)) +
  theme(panel.background = element_blank(),
          panel.grid = element_blank(),
          panel.grid.major.y = element_line(size = 0.25, color = gray(0.95)),
          axis.ticks.y = element_blank(),
          panel.border = element_blank(),
          strip.text = element_text(size = 12),
          plot.caption = element_text(size = 9, hjust = 0, margin = margin(t = 15)),
          strip.background = element_blank()) +
  labs(x = "Coefficient estimate and 95% CI", y=NULL,
      title=NULL, subtitle=NULL) +
  facet_wrap(~model+spec, ncol = 4, labeller = label_parsed)
dev.off()
