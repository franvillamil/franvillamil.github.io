## Replication files for 'Civilian victimization and ethnic civil war'
## Lars-Erik Cederman, Simon Hug, Livia Schubiger and Francisco Villamil
## Journal of Conflict Resolution
## --------------------
## ANALYSES: MODEL, TABLES AND FIGURES

## PREAMBLE ---------------------------------------------------------

Working directory
if(!grepl("replication$", getwd())){
  print("Choose any file in the replication folder (e.g. analyses.R)")
  dir = file.choose()
  setwd(gsub("\\w*\\..*", "", dir))
}

# Packages; if not available, install
packages = c("arm", "texreg", "stargazer", "stringr",
  "countrycode", "MASS", "sandwich", "lmtest", "car",
  "xtable", "plyr", "dplyr", "corrplot", "plotrix")
if(!all(packages %in% rownames(installed.packages()))){
  install.packages(packages[!packages %in% rownames(installed.packages())])
} else {lapply(packages, require, character.only = TRUE)}

# Options
options(stringsAsFactors = FALSE)

# Load functions
source("table_function.R")
source("oprobit_pp_functions.R")

## ==================================================================
## PREPARATION ------------------------------------------------------

# Load data
data = read.csv("dataset.csv")

# Variable creation
data$prior_rebel = ifelse(data$family_warhist > 0, 1, 0)
data$prior_rebel_incumb = ifelse(data$family_warhist > 0 | data$prev_conf_recipient > 0, 1, 0)
data$IntLevel = factor(data$intensity_level)

## ==================================================================
## MODELS MAIN TEXT -------------------------------------------------

# Base model
t1 = bayespolr(IntLevel ~
  Target_Gov_l1 * int_level1_lag +
  Target_Gov_l1 * int_level2_lag +
  status_excl + status_excl * int_level1_lag + status_excl  * int_level2_lag+
  downgraded2 + downgraded2 * int_level1_lag + downgraded2  * int_level2_lag+
  family_warhist +  family_warhist * int_level1_lag +  family_warhist  * int_level2_lag+
  ln_pop_l +   ln_pop_l * int_level1_lag +   ln_pop_l  * int_level2_lag+
  ln_gdppc_l +  ln_gdppc_l * int_level1_lag +  ln_gdppc_l  * int_level2_lag+
  groupsize + groupsize * int_level1_lag + groupsize  * int_level2_lag+
  cincidence_flag_l +cincidence_flag_l * int_level1_lag +cincidence_flag_l  * int_level2_lag+
  as.factor(peaceyrs_lowint) +
  waryrs_lowint + I(waryrs_lowint*waryrs_lowint) + I(waryrs_lowint*waryrs_lowint*waryrs_lowint) +
  waryrs_highint + I(waryrs_highint*waryrs_highint)+I(waryrs_highint*waryrs_highint*waryrs_highint),
  data = data, method = "probit", Hess = TRUE)

print_oprobit(model = t1, recode =
  "'int_level1_lag' = 'Low intensity conflict$_{t-1}$';
  'int_level2_lag' = 'High intensity conflict$_{t-1}$';
  'Target_Gov_l1' = 'Ethnic targeting$_{t-1}$';
  'status_excl' = 'Status excluded';
  'downgraded2' = 'Downgraded';
  'family_warhist' = 'Previous conflicts';
  'ln_pop_l' = 'Log. Population$_{t-1}$';
  'ln_gdppc_l' = 'Log. GDPpc$_{t-1}$';
  'groupsize' = 'Group size';
  'cincidence_flag_l' = 'Ongoing conflict$_{t-1}$'")

# Model with prior conflict interaction
t2 = bayespolr(IntLevel ~
  Target_Gov_l1 * int_level1_lag * fam_warhist2_dummy +
  Target_Gov_l1 * int_level2_lag * fam_warhist2_dummy +
  status_excl + status_excl * int_level1_lag + status_excl  * int_level2_lag+
  downgraded2 + downgraded2 * int_level1_lag + downgraded2  * int_level2_lag+
  ln_pop_l +   ln_pop_l * int_level1_lag + ln_pop_l  * int_level2_lag+
  ln_gdppc_l +  ln_gdppc_l * int_level1_lag + ln_gdppc_l  * int_level2_lag+
  groupsize + groupsize * int_level1_lag + groupsize  * int_level2_lag+
  cincidence_flag_l +cincidence_flag_l * int_level1_lag +cincidence_flag_l  * int_level2_lag+
  as.factor(peaceyrs_lowint) +
  waryrs_lowint + I(waryrs_lowint*waryrs_lowint) + I(waryrs_lowint*waryrs_lowint*waryrs_lowint) +
  waryrs_highint + I(waryrs_highint*waryrs_highint)+I(waryrs_highint*waryrs_highint*waryrs_highint),
  data = data, method = "probit", Hess = TRUE)

print_oprobit(model = t2, recode =
  "'int_level1_lag' = 'Low intensity conflict$_{t-1}$';
  'int_level2_lag' = 'High intensity conflict$_{t-1}$';
  'Target_Gov_l1' = 'Ethnic targeting$_{t-1}$';
  'status_excl' = 'Status excluded';
  'downgraded2' = 'Downgraded';
  'family_warhist' = 'Previous conflicts';
  'ln_pop_l' = 'Log. Population$_{t-1}$';
  'ln_gdppc_l' = 'Log. GDPpc$_{t-1}$';
  'v2x_libdem_l' = 'Lib. democracy index$_{t-1}$';
  'groupsize' = 'Group size';
  'cincidence_flag_l' = 'Ongoing conflict$_{t-1}$';
  'fam_warhist2_dummy' = 'Prior conflict'")

## FIGURES MAIN TEXT ------------------------------------------------

## Base model

# Model matrix and simulations
model = t1
rtr = model.matrix(model)
sim = sim(model, n.sims = 1000)

pp<-array(NA,dim=c(nrow(sim@coef),3))
pp0<-array(NA,dim=c(nrow(sim@coef),3))
pp2<-array(NA,dim=c(nrow(sim@coef),3))
pp30<-array(NA,dim=c(nrow(sim@coef),3))
pp3<-array(NA,dim=c(nrow(sim@coef),3))
pp40<-array(NA,dim=c(nrow(sim@coef),3))
pp4<-array(NA,dim=c(nrow(sim@coef),3))

for (i in 1:nrow(sim@coef)){
  print(i)
  ##pp0 no osv in peacetime predictions
  xbsim = gen_xbsim(osv = 0, int_level = 0)
  pp0 = fill_pp(pp0)
  ##pp2 osv in peacetime predictions
  xbsim = gen_xbsim(osv = 1, int_level = 0)
  pp2 = fill_pp(pp2)
  ##pp30 no osv in low-intensity predictions
  xbsim = gen_xbsim(osv = 0, int_level = 1)
  pp30 = fill_pp(pp30)
  ##pp3 osv in low-intensity predictions
  xbsim = gen_xbsim(osv = 1, int_level = 1)
  pp3 = fill_pp(pp3)
  ##pp40 no osv in high-intensity predictions
  xbsim = gen_xbsim(osv = 0, int_level = 2)
  pp40 = fill_pp(pp40)
  ##pp4 osv in high-intensity predictions
  xbsim = gen_xbsim(osv = 1, int_level = 2)
  pp4 = fill_pp(pp4)
}

tt_base <- rbind(
  quantile(pp2[,1]-pp0[,1],c(0.025,0.5,0.975)),
  quantile(pp2[,2]-pp0[,2],c(0.025,0.5,0.975)),
  quantile(pp2[,3]-pp0[,3],c(0.025,0.5,0.975)),

  quantile(pp3[,1]-pp30[,1],c(0.025,0.5,0.975)),
  quantile(pp3[,2]-pp30[,2],c(0.025,0.5,0.975)),
  quantile(pp3[,3]-pp30[,3],c(0.025,0.5,0.975)),

  quantile(pp4[,1]-pp40[,1],c(0.025,0.5,0.975)),
  quantile(pp4[,2]-pp40[,2],c(0.025,0.5,0.975)),
  quantile(pp4[,3]-pp40[,3],c(0.025,0.5,0.975)))

tt = tt_base

pdf("predp_base.pdf")
par(mfrow = c(3,1))

plotCI(tt[c(3,2,1),2],seq(1:3),li=tt[c(3,2,1),1],
ui=tt[c(3,2,1),3],err="x",pch=0,xlim=c(-.35,.35),yaxt="n",
ylab="",xlab="Change in transition probabilities", main="Effect of state-led ethnic targeting during peacetime")
abline(v=0)
text(0.237,2.9,"Remain in peacetime")
text(0.237,2,"Transition to low-intensity conflict")
text(0.237,1.1,"Transition to high-intensity conflict")

plotCI(tt[c(6,5,4),2],seq(1:3),li=tt[c(6,5,4),1],
ui=tt[c(6,5,4),3],err="x",pch=0,xlim=c(-.35,.35),yaxt="n",
ylab="",xlab="Change in transition probabilities", main="Effect of state-led ethnic targeting during low-intensity conflicts")
abline(v=0)
text(0.237,2.9,"Transition to peace")
text(0.237,2,"Remain as low-intensity conflict")
text(0.237,1.1,"Transition to high-intensity conflict")

plotCI(tt[c(9,8,7),2],seq(1:3),li=tt[c(9,8,7),1],
ui=tt[c(9,8,7),3],err="x",pch=0,xlim=c(-.35,.35),yaxt="n",
ylab="",xlab="Change in transition probabilities", main="Effect of state-led ethnic targeting during high-intensity conflicts")
abline(v=0)
text(0.237,2.9,"Transition to peace")
text(0.237,2,"Transition to low-intensity conflict")
text(0.237,1.1,"Remain as high-intensity conflict")

abline(v=0)
dev.off()

## Model 2: Warhist_dummy2 = 0

# Model matrix and simulations
model = t2
rtr = model.matrix(model)
sim = sim(model, n.sims = 1000)

pp<-array(NA,dim=c(nrow(sim@coef),3))
pp0<-array(NA,dim=c(nrow(sim@coef),3))
pp2<-array(NA,dim=c(nrow(sim@coef),3))
pp30<-array(NA,dim=c(nrow(sim@coef),3))
pp3<-array(NA,dim=c(nrow(sim@coef),3))
pp40<-array(NA,dim=c(nrow(sim@coef),3))
pp4<-array(NA,dim=c(nrow(sim@coef),3))


for (i in 1:nrow(sim@coef)){
  print(i)
  ##pp0 no osv in peacetime predictions
  xbsim = gen_xbsim(osv = 0, int_level = 0)
  xbsim = set_fam_warhist2_dummy(xbsim, 0)
  pp0 = fill_pp(pp0)
  ##pp2 osv in peacetime predictions
  xbsim = gen_xbsim(osv = 1, int_level = 0)
  xbsim = set_fam_warhist2_dummy(xbsim, 0)
  pp2 = fill_pp(pp2)
  ##pp30 no osv in low-intensity predictions
  xbsim = gen_xbsim(osv = 0, int_level = 1)
  xbsim = set_fam_warhist2_dummy(xbsim, 0)
  pp30 = fill_pp(pp30)
  ##pp3 osv in low-intensity predictions
  xbsim = gen_xbsim(osv = 1, int_level = 1)
  xbsim = set_fam_warhist2_dummy(xbsim, 0)
  pp3 = fill_pp(pp3)
  ##pp40 no osv in high-intensity predictions
  xbsim = gen_xbsim(osv = 0, int_level = 2)
  xbsim = set_fam_warhist2_dummy(xbsim, 0)
  pp40 = fill_pp(pp40)
  ##pp4 osv in high-intensity predictions
  xbsim = gen_xbsim(osv = 1, int_level = 2)
  xbsim = set_fam_warhist2_dummy(xbsim, 0)
  pp4 = fill_pp(pp4)
}

tt_whist0 <- rbind(quantile(pp2[,1]-pp0[,1],c(0.025,0.5,0.975)),
  quantile(pp2[,2]-pp0[,2],c(0.025,0.5,0.975)),
  quantile(pp2[,3]-pp0[,3],c(0.025,0.5,0.975)),

  quantile(pp3[,1]-pp30[,1],c(0.025,0.5,0.975)),
  quantile(pp3[,2]-pp30[,2],c(0.025,0.5,0.975)),
  quantile(pp3[,3]-pp30[,3],c(0.025,0.5,0.975)),

  quantile(pp4[,1]-pp40[,1],c(0.025,0.5,0.975)),
  quantile(pp4[,2]-pp40[,2],c(0.025,0.5,0.975)),
  quantile(pp4[,3]-pp40[,3],c(0.025,0.5,0.975)))

tt = tt_whist0

pdf("predp_whist2_0.pdf")
par(mfrow = c(3,1))

plotCI(tt[c(3,2,1),2],seq(1:3),li=tt[c(3,2,1),1],
ui=tt[c(3,2,1),3],err="x",pch=0,xlim=c(-.35,.35),yaxt="n",
ylab="",xlab="Change in transition probabilities", main="Effect of state-led ethnic targeting during peacetime (first conflict cycle)")
abline(v=0)
text(0.237,2.9,"Remain in peacetime")
text(0.237,2,"Transition to low-intensity conflict")
text(0.237,1.1,"Transition to high-intensity conflict")

plotCI(tt[c(6,5,4),2],seq(1:3),li=tt[c(6,5,4),1],
ui=tt[c(6,5,4),3],err="x",pch=0,xlim=c(-.35,.35),yaxt="n",
ylab="",xlab="Change in transition probabilities", main="Effect of state-led ethnic targeting during low-intensity conflicts (first conflict cycle)")
abline(v=0)
text(0.237,2.9,"Transition to peace")
text(0.237,2,"Remain as low-intensity conflict")
text(0.237,1.1,"Transition to high-intensity conflict")

plotCI(tt[c(9,8,7),2],seq(1:3),li=tt[c(9,8,7),1],
ui=tt[c(9,8,7),3],err="x",pch=0,xlim=c(-.35,.35),yaxt="n",
ylab="",xlab="Change in transition probabilities", main="Effect of state-led ethnic targeting during high-intensity conflicts (first conflict cycle)")
abline(v=0)
text(0.237,2.9,"Transition to peace")
text(0.237,2,"Transition to low-intensity conflict")
text(0.237,1.1,"Remain as high-intensity conflict")

abline(v=0)
dev.off()

## Model 2: Warhist_dummy2 = 1

# Model matrix and simulations
model = t2
rtr = model.matrix(model)
sim = sim(model, n.sims = 1000)

pp<-array(NA,dim=c(nrow(sim@coef),3))
pp0<-array(NA,dim=c(nrow(sim@coef),3))
pp2<-array(NA,dim=c(nrow(sim@coef),3))
pp30<-array(NA,dim=c(nrow(sim@coef),3))
pp3<-array(NA,dim=c(nrow(sim@coef),3))
pp40<-array(NA,dim=c(nrow(sim@coef),3))
pp4<-array(NA,dim=c(nrow(sim@coef),3))


for (i in 1:nrow(sim@coef)){
  print(i)
  ##pp0 no osv in peacetime predictions
  xbsim = gen_xbsim(osv = 0, int_level = 0)
  xbsim = set_fam_warhist2_dummy(xbsim, 1)
  pp0 = fill_pp(pp0)
  ##pp2 osv in peacetime predictions
  xbsim = gen_xbsim(osv = 1, int_level = 0)
  xbsim = set_fam_warhist2_dummy(xbsim, 1)
  pp2 = fill_pp(pp2)
  ##pp30 no osv in low-intensity predictions
  xbsim = gen_xbsim(osv = 0, int_level = 1)
  xbsim = set_fam_warhist2_dummy(xbsim, 1)
  pp30 = fill_pp(pp30)
  ##pp3 osv in low-intensity predictions
  xbsim = gen_xbsim(osv = 1, int_level = 1)
  xbsim = set_fam_warhist2_dummy(xbsim, 1)
  pp3 = fill_pp(pp3)
  ##pp40 no osv in high-intensity predictions
  xbsim = gen_xbsim(osv = 0, int_level = 2)
  xbsim = set_fam_warhist2_dummy(xbsim, 1)
  pp40 = fill_pp(pp40)
  ##pp4 osv in high-intensity predictions
  xbsim = gen_xbsim(osv = 1, int_level = 2)
  xbsim = set_fam_warhist2_dummy(xbsim, 1)
  pp4 = fill_pp(pp4)
}

tt_whist1 <- rbind(quantile(pp2[,1]-pp0[,1],c(0.025,0.5,0.975)),
  quantile(pp2[,2]-pp0[,2],c(0.025,0.5,0.975)),
  quantile(pp2[,3]-pp0[,3],c(0.025,0.5,0.975)),

  quantile(pp3[,1]-pp30[,1],c(0.025,0.5,0.975)),
  quantile(pp3[,2]-pp30[,2],c(0.025,0.5,0.975)),
  quantile(pp3[,3]-pp30[,3],c(0.025,0.5,0.975)),

  quantile(pp4[,1]-pp40[,1],c(0.025,0.5,0.975)),
  quantile(pp4[,2]-pp40[,2],c(0.025,0.5,0.975)),
  quantile(pp4[,3]-pp40[,3],c(0.025,0.5,0.975)))

tt = tt_whist1

pdf("predp_whist2_1.pdf")
par(mfrow = c(3,1))

plotCI(tt[c(3,2,1),2],seq(1:3),li=tt[c(3,2,1),1],
ui=tt[c(3,2,1),3],err="x",pch=0,xlim=c(-.35,.35),yaxt="n",
ylab="",xlab="Change in transition probabilities", main="Effect of state-led ethnic targeting during peacetime (second+ conflict cycle)")
abline(v=0)
text(0.237,2.9,"Remain in peacetime")
text(0.237,2,"Transition to low-intensity conflict")
text(0.237,1.1,"Transition to high-intensity conflict")

plotCI(tt[c(6,5,4),2],seq(1:3),li=tt[c(6,5,4),1],
ui=tt[c(6,5,4),3],err="x",pch=0,xlim=c(-.35,.35),yaxt="n",
ylab="",xlab="Change in transition probabilities", main="Effect of state-led ethnic targeting during low-intensity conflicts (second+ conflict cycle)")
abline(v=0)
text(0.237,2.9,"Transition to peace")
text(0.237,2,"Remain as low-intensity conflict")
text(0.237,1.1,"Transition to high-intensity conflict")

plotCI(tt[c(9,8,7),2],seq(1:3),li=tt[c(9,8,7),1],
ui=tt[c(9,8,7),3],err="x",pch=0,xlim=c(-.35,.35),yaxt="n",
ylab="",xlab="Change in transition probabilities", main="Effect of state-led ethnic targeting during high-intensity conflicts (second+ conflict cycle)")
abline(v=0)
text(0.237,2.9,"Transition to peace")
text(0.237,2,"Transition to low-intensity conflict")
text(0.237,1.1,"Remain as high-intensity conflict")

abline(v=0)
dev.off()

## ==================================================================
## MODELS APPENDIX --------------------------------------------------

# Base model with EOSV in last 2 years
t1b = bayespolr(IntLevel ~
  Target_Gov_l2 * int_level1_lag +
  Target_Gov_l2 * int_level2_lag +
  status_excl + status_excl * int_level1_lag + status_excl  * int_level2_lag+
  downgraded2 + downgraded2 * int_level1_lag + downgraded2  * int_level2_lag+
  family_warhist +  family_warhist * int_level1_lag +  family_warhist  * int_level2_lag+
  ln_pop_l +   ln_pop_l * int_level1_lag +   ln_pop_l  * int_level2_lag+
  ln_gdppc_l +  ln_gdppc_l * int_level1_lag +  ln_gdppc_l  * int_level2_lag+
  groupsize + groupsize * int_level1_lag + groupsize  * int_level2_lag+
  cincidence_flag_l +cincidence_flag_l * int_level1_lag +cincidence_flag_l  * int_level2_lag+
  as.factor(peaceyrs_lowint) +
  waryrs_lowint + I(waryrs_lowint*waryrs_lowint) + I(waryrs_lowint*waryrs_lowint*waryrs_lowint) +
  waryrs_highint + I(waryrs_highint*waryrs_highint)+I(waryrs_highint*waryrs_highint*waryrs_highint),
  data = data, method = "probit", Hess = TRUE)

print_oprobit(t1b, recode =
  "'int_level1_lag' = 'Low intensity conflict$_{t-1}$';
  'int_level2_lag' = 'High intensity conflict$_{t-1}$';
  'Target_Gov_l2' = 'Ethnic targeting$_{t-1, t-2}$';
  'status_excl' = 'Status excluded';
  'downgraded2' = 'Downgraded';
  'family_warhist' = 'Previous conflicts';
  'ln_pop_l' = 'Log. Population$_{t-1}$';
  'ln_gdppc_l' = 'Log. GDPpc$_{t-1}$';
  'groupsize' = 'Group size';
  'cincidence_flag_l' = 'Ongoing conflict$_{t-1}$';
  'fam_warhist2_dummy' = 'Prior conflict'")

# Interaction model with EOSV in last 2 years
t2b = bayespolr(IntLevel ~
  Target_Gov_l2 * int_level1_lag * fam_warhist2_dummy +
  Target_Gov_l2 * int_level2_lag * fam_warhist2_dummy +
  status_excl + status_excl * int_level1_lag + status_excl  * int_level2_lag+
  downgraded2 + downgraded2 * int_level1_lag + downgraded2  * int_level2_lag+
  ln_pop_l +   ln_pop_l * int_level1_lag +   ln_pop_l  * int_level2_lag+
  ln_gdppc_l +  ln_gdppc_l * int_level1_lag +  ln_gdppc_l  * int_level2_lag+
  groupsize + groupsize * int_level1_lag + groupsize  * int_level2_lag+
  cincidence_flag_l +cincidence_flag_l * int_level1_lag +cincidence_flag_l  * int_level2_lag+
  as.factor(peaceyrs_lowint) +
  waryrs_lowint + I(waryrs_lowint*waryrs_lowint) + I(waryrs_lowint*waryrs_lowint*waryrs_lowint) +
  waryrs_highint + I(waryrs_highint*waryrs_highint)+I(waryrs_highint*waryrs_highint*waryrs_highint),
  data = data, method = "probit", Hess = TRUE)

print_oprobit(t2b, recode =
  "'int_level1_lag' = 'Low intensity conflict$_{t-1}$';
  'int_level2_lag' = 'High intensity conflict$_{t-1}$';
  'Target_Gov_l2' = 'Ethnic targeting$_{t-1, t-2}$';
  'status_excl' = 'Status excluded';
  'downgraded2' = 'Downgraded';
  'family_warhist' = 'Previous conflicts';
  'ln_pop_l' = 'Log. Population$_{t-1}$';
  'ln_gdppc_l' = 'Log. GDPpc$_{t-1}$';
  'groupsize' = 'Group size';
  'cincidence_flag_l' = 'Ongoing conflict$_{t-1}$';
  'fam_warhist2_dummy' = 'Prior conflict'")

# Base model, including liberal democracy (V-Dem) index
t1_incl_vdem = bayespolr(IntLevel ~
  Target_Gov_l1 * int_level1_lag +
  Target_Gov_l1 * int_level2_lag +
  status_excl + status_excl * int_level1_lag + status_excl  * int_level2_lag+
  downgraded2 + downgraded2 * int_level1_lag + downgraded2  * int_level2_lag+
  family_warhist +  family_warhist * int_level1_lag +  family_warhist  * int_level2_lag+
  ln_pop_l +   ln_pop_l * int_level1_lag +   ln_pop_l  * int_level2_lag+
  ln_gdppc_l +  ln_gdppc_l * int_level1_lag +  ln_gdppc_l  * int_level2_lag+
  v2x_libdem_l + v2x_libdem_l * int_level1_lag + v2x_libdem_l * int_level2_lag +
  groupsize + groupsize * int_level1_lag + groupsize  * int_level2_lag+
  cincidence_flag_l +cincidence_flag_l * int_level1_lag +cincidence_flag_l  * int_level2_lag+
  as.factor(peaceyrs_lowint) +
  waryrs_lowint + I(waryrs_lowint*waryrs_lowint) + I(waryrs_lowint*waryrs_lowint*waryrs_lowint) +
  waryrs_highint + I(waryrs_highint*waryrs_highint)+I(waryrs_highint*waryrs_highint*waryrs_highint),
  data = data, method = "probit", Hess = TRUE)

print_oprobit(model = t1_incl_vdem, recode =
  "'int_level1_lag' = 'Low intensity conflict$_{t-1}$';
  'int_level2_lag' = 'High intensity conflict$_{t-1}$';
  'Target_Gov_l1' = 'Ethnic targeting$_{t-1}$';
  'status_excl' = 'Status excluded';
  'downgraded2' = 'Downgraded';
  'family_warhist' = 'Previous conflicts';
  'ln_pop_l' = 'Log. Population$_{t-1}$';
  'ln_gdppc_l' = 'Log. GDPpc$_{t-1}$';
  'groupsize' = 'Group size';
  'v2x_libdem_l' = 'Lib. democracy index$_{t-1}$';
  'cincidence_flag_l' = 'Ongoing conflict$_{t-1}$'")

# Interaction model, including liberal democracy (V-Dem) index
t2_incl_vdem = bayespolr(IntLevel ~
  Target_Gov_l1 * int_level1_lag * fam_warhist2_dummy +
  Target_Gov_l1 * int_level2_lag * fam_warhist2_dummy +
  status_excl + status_excl * int_level1_lag + status_excl  * int_level2_lag+
  downgraded2 + downgraded2 * int_level1_lag + downgraded2  * int_level2_lag+
  ln_pop_l +   ln_pop_l * int_level1_lag + ln_pop_l  * int_level2_lag+
  ln_gdppc_l +  ln_gdppc_l * int_level1_lag + ln_gdppc_l  * int_level2_lag+
  v2x_libdem_l + v2x_libdem_l * int_level1_lag + v2x_libdem_l * int_level2_lag +
  groupsize + groupsize * int_level1_lag + groupsize  * int_level2_lag+
  cincidence_flag_l +cincidence_flag_l * int_level1_lag +cincidence_flag_l  * int_level2_lag+
  as.factor(peaceyrs_lowint) +
  waryrs_lowint + I(waryrs_lowint*waryrs_lowint) + I(waryrs_lowint*waryrs_lowint*waryrs_lowint) +
  waryrs_highint + I(waryrs_highint*waryrs_highint)+I(waryrs_highint*waryrs_highint*waryrs_highint),
  data = data, method = "probit", Hess = TRUE)

print_oprobit(model = t2_incl_vdem, recode =
  "'int_level1_lag' = 'Low intensity conflict$_{t-1}$';
  'int_level2_lag' = 'High intensity conflict$_{t-1}$';
  'Target_Gov_l1' = 'Ethnic targeting$_{t-1}$';
  'status_excl' = 'Status excluded';
  'downgraded2' = 'Downgraded';
  'family_warhist' = 'Previous conflicts';
  'ln_pop_l' = 'Log. Population$_{t-1}$';
  'ln_gdppc_l' = 'Log. GDPpc$_{t-1}$';
  'v2x_libdem_l' = 'Lib. democracy index$_{t-1}$';
  'groupsize' = 'Group size';
  'cincidence_flag_l' = 'Ongoing conflict$_{t-1}$';
  'fam_warhist2_dummy' = 'Prior conflict'")

# Interaction model with groupsize
t_gsize = bayespolr(IntLevel ~
  Target_Gov_l1 * int_level1_lag * groupsize +
  Target_Gov_l1 * int_level2_lag * groupsize +
  status_excl + status_excl * int_level1_lag + status_excl  * int_level2_lag+
  downgraded2 + downgraded2 * int_level1_lag + downgraded2  * int_level2_lag+
  family_warhist +  family_warhist * int_level1_lag +  family_warhist  * int_level2_lag+
  ln_pop_l +   ln_pop_l * int_level1_lag +   ln_pop_l  * int_level2_lag+
  ln_gdppc_l +  ln_gdppc_l * int_level1_lag +  ln_gdppc_l  * int_level2_lag+
  cincidence_flag_l +cincidence_flag_l * int_level1_lag +cincidence_flag_l  * int_level2_lag+
  as.factor(peaceyrs_lowint) +
  waryrs_lowint + I(waryrs_lowint*waryrs_lowint) + I(waryrs_lowint*waryrs_lowint*waryrs_lowint) +
  waryrs_highint + I(waryrs_highint*waryrs_highint)+I(waryrs_highint*waryrs_highint*waryrs_highint),
  data = data, method = "probit", Hess = TRUE)

print_oprobit(t_gsize, recode =
  "'int_level1_lag' = 'Low intensity conflict$_{t-1}$';
  'int_level2_lag' = 'High intensity conflict$_{t-1}$';
  'Target_Gov_l1' = 'Ethnic targeting$_{t-1}$';
  'status_excl' = 'Status excluded';
  'downgraded2' = 'Downgraded';
  'family_warhist' = 'Previous conflicts';
  'ln_pop_l' = 'Log. Population$_{t-1}$';
  'ln_gdppc_l' = 'Log. GDPpc$_{t-1}$';
  'v2x_libdem_l' = 'Lib. democracy index$_{t-1}$';
  'groupsize' = 'Group size';
  'cincidence_flag_l' = 'Ongoing conflict$_{t-1}$';
  'fam_warhist2_dummy' = 'Prior conflict'")


## FIGURES APPENDIX ----------------------------------------------

## Model groupsize = 0.2

model = t_gsize
rtr = model.matrix(model)
sim = sim(model, n.sims = 1000)

pp<-array(NA,dim=c(nrow(sim@coef),3))
pp0<-array(NA,dim=c(nrow(sim@coef),3))
pp2<-array(NA,dim=c(nrow(sim@coef),3))
pp30<-array(NA,dim=c(nrow(sim@coef),3))
pp3<-array(NA,dim=c(nrow(sim@coef),3))
pp40<-array(NA,dim=c(nrow(sim@coef),3))
pp4<-array(NA,dim=c(nrow(sim@coef),3))

for (i in 1:nrow(sim@coef)){
  print(i)
  ##pp0 no osv in peacetime predictions
  xbsim = gen_xbsim(osv = 0, int_level = 0)
  xbsim = set_groupsize(xbsim, 0.2)
  pp0 = fill_pp(pp0)
  ##pp2 osv in peacetime predictions
  xbsim = gen_xbsim(osv = 1, int_level = 0)
  xbsim = set_groupsize(xbsim, 0.2)
  pp2 = fill_pp(pp2)
  ##pp30 no osv in low-intensity predictions
  xbsim = gen_xbsim(osv = 0, int_level = 1)
  xbsim = set_groupsize(xbsim, 0.2)
  pp30 = fill_pp(pp30)
  ##pp3 osv in low-intensity predictions
  xbsim = gen_xbsim(osv = 1, int_level = 1)
  xbsim = set_groupsize(xbsim, 0.2)
  pp3 = fill_pp(pp3)
  ##pp40 no osv in high-intensity predictions
  xbsim = gen_xbsim(osv = 0, int_level = 2)
  xbsim = set_groupsize(xbsim, 0.2)
  pp40 = fill_pp(pp40)
  ##pp4 osv in high-intensity predictions
  xbsim = gen_xbsim(osv = 1, int_level = 2)
  xbsim = set_groupsize(xbsim, 0.2)
  pp4 = fill_pp(pp4)
}

tt_gsize0 <- rbind(quantile(pp2[,1]-pp0[,1],c(0.025,0.5,0.975)),
  quantile(pp2[,2]-pp0[,2],c(0.025,0.5,0.975)),
  quantile(pp2[,3]-pp0[,3],c(0.025,0.5,0.975)),

  quantile(pp3[,1]-pp30[,1],c(0.025,0.5,0.975)),
  quantile(pp3[,2]-pp30[,2],c(0.025,0.5,0.975)),
  quantile(pp3[,3]-pp30[,3],c(0.025,0.5,0.975)),

  quantile(pp4[,1]-pp40[,1],c(0.025,0.5,0.975)),
  quantile(pp4[,2]-pp40[,2],c(0.025,0.5,0.975)),
  quantile(pp4[,3]-pp40[,3],c(0.025,0.5,0.975)))

tt = tt_gsize0

pdf("predp_groupsize02.pdf")
par(mfrow = c(3,1))

plotCI(tt[c(3,2,1),2],seq(1:3),li=tt[c(3,2,1),1],
ui=tt[c(3,2,1),3],err="x",pch=0,xlim=c(-.5,.5),yaxt="n",
ylab="",xlab="Change in transition probabilities", main="Effect of state-led ethnic targeting during peacetime (groupsize = 0.2)")
abline(v=0)
text(0.237,2.9,"Remain in peacetime")
text(0.237,2,"Transition to low-intensity conflict")
text(0.237,1.1,"Transition to high-intensity conflict")

plotCI(tt[c(6,5,4),2],seq(1:3),li=tt[c(6,5,4),1],
ui=tt[c(6,5,4),3],err="x",pch=0,xlim=c(-.5,.5),yaxt="n",
ylab="",xlab="Change in transition probabilities", main="Effect of state-led ethnic targeting during low-intensity conflicts (groupsize = 0.2)")
abline(v=0)
text(0.237,2.9,"Transition to peace")
text(0.237,2,"Remain as low-intensity conflict")
text(0.237,1.1,"Transition to high-intensity conflict")

plotCI(tt[c(9,8,7),2],seq(1:3),li=tt[c(9,8,7),1],
ui=tt[c(9,8,7),3],err="x",pch=0,xlim=c(-.5,.5),yaxt="n",
ylab="",xlab="Change in transition probabilities", main="Effect of state-led ethnic targeting during high-intensity conflicts (groupsize = 0.2)")
abline(v=0)
text(0.237,2.9,"Transition to peace")
text(0.237,2,"Transition to low-intensity conflict")
text(0.237,1.1,"Remain as high-intensity conflict")

abline(v=0)
dev.off()

## Model groupsize = 0.2

pp<-array(NA,dim=c(nrow(sim@coef),3))
pp0<-array(NA,dim=c(nrow(sim@coef),3))
pp2<-array(NA,dim=c(nrow(sim@coef),3))
pp30<-array(NA,dim=c(nrow(sim@coef),3))
pp3<-array(NA,dim=c(nrow(sim@coef),3))
pp40<-array(NA,dim=c(nrow(sim@coef),3))
pp4<-array(NA,dim=c(nrow(sim@coef),3))

for (i in 1:nrow(sim@coef)){
  print(i)
  ##pp0 no osv in peacetime predictions
  xbsim = gen_xbsim(osv = 0, int_level = 0)
  xbsim = set_groupsize(xbsim, 0.8)
  pp0 = fill_pp(pp0)
  ##pp2 osv in peacetime predictions
  xbsim = gen_xbsim(osv = 1, int_level = 0)
  xbsim = set_groupsize(xbsim, 0.8)
  pp2 = fill_pp(pp2)
  ##pp30 no osv in low-intensity predictions
  xbsim = gen_xbsim(osv = 0, int_level = 1)
  xbsim = set_groupsize(xbsim, 0.8)
  pp30 = fill_pp(pp30)
  ##pp3 osv in low-intensity predictions
  xbsim = gen_xbsim(osv = 1, int_level = 1)
  xbsim = set_groupsize(xbsim, 0.8)
  pp3 = fill_pp(pp3)
  ##pp40 no osv in high-intensity predictions
  xbsim = gen_xbsim(osv = 0, int_level = 2)
  xbsim = set_groupsize(xbsim, 0.8)
  pp40 = fill_pp(pp40)
  ##pp4 osv in high-intensity predictions
  xbsim = gen_xbsim(osv = 1, int_level = 2)
  xbsim = set_groupsize(xbsim, 0.8)
  pp4 = fill_pp(pp4)
}

tt_gsize1 <- rbind(quantile(pp2[,1]-pp0[,1],c(0.025,0.5,0.975)),
  quantile(pp2[,2]-pp0[,2],c(0.025,0.5,0.975)),
  quantile(pp2[,3]-pp0[,3],c(0.025,0.5,0.975)),

  quantile(pp3[,1]-pp30[,1],c(0.025,0.5,0.975)),
  quantile(pp3[,2]-pp30[,2],c(0.025,0.5,0.975)),
  quantile(pp3[,3]-pp30[,3],c(0.025,0.5,0.975)),

  quantile(pp4[,1]-pp40[,1],c(0.025,0.5,0.975)),
  quantile(pp4[,2]-pp40[,2],c(0.025,0.5,0.975)),
  quantile(pp4[,3]-pp40[,3],c(0.025,0.5,0.975)))

tt = tt_gsize1

pdf("predp_groupsize08.pdf")
par(mfrow = c(3,1))

plotCI(tt[c(3,2,1),2],seq(1:3),li=tt[c(3,2,1),1],
ui=tt[c(3,2,1),3],err="x",pch=0,xlim=c(-.5,.5),yaxt="n",
ylab="",xlab="Change in transition probabilities", main="Effect of state-led ethnic targeting during peacetime (groupsize = 0.8)")
abline(v=0)
text(0.237,2.9,"Remain in peacetime")
text(0.237,2,"Transition to low-intensity conflict")
text(0.237,1.1,"Transition to high-intensity conflict")

plotCI(tt[c(6,5,4),2],seq(1:3),li=tt[c(6,5,4),1],
ui=tt[c(6,5,4),3],err="x",pch=0,xlim=c(-.5,.5),yaxt="n",
ylab="",xlab="Change in transition probabilities", main="Effect of state-led ethnic targeting during low-intensity conflicts (groupsize = 0.8)")
abline(v=0)
text(0.237,2.9,"Transition to peace")
text(0.237,2,"Remain as low-intensity conflict")
text(0.237,1.1,"Transition to high-intensity conflict")

plotCI(tt[c(9,8,7),2],seq(1:3),li=tt[c(9,8,7),1],
ui=tt[c(9,8,7),3],err="x",pch=0,xlim=c(-.5,.5),yaxt="n",
ylab="",xlab="Change in transition probabilities", main="Effect of state-led ethnic targeting during high-intensity conflicts (groupsize = 0.8)")
abline(v=0)
text(0.237,2.9,"Transition to peace")
text(0.237,2,"Transition to low-intensity conflict")
text(0.237,1.1,"Remain as high-intensity conflict")

abline(v=0)
dev.off()
