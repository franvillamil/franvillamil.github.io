# Functions: generate X matrix and calculate pred prob
gen_xbsim = function(osv, int_level){
  # base
  output = rtr[,c(2:ncol(rtr))]
  # OSV
  if (osv == 1){
  output[,"Target_Gov_l1"] = 1
  ci = which(grepl("Target_Gov_l1:|:Target_Gov_l1", colnames(output)))
  ci2 = gsub(":Target_Gov_l1|:Target_Gov_l1:|Target_Gov_l1:", "", colnames(output)[ci])
  output[,ci] = output[,ci2]
  } else if (osv == 0){
    output[,"Target_Gov_l1"] = 0
    ci = which(grepl("Target_Gov_l1:|:Target_Gov_l1", colnames(output)))
    ci2 = gsub(":Target_Gov_l1|:Target_Gov_l1:|Target_Gov_l1:", "", colnames(output)[ci])
    output[,ci] = 0
  } else {stop("osv?")}
  # Int level
  if (int_level == 0){
    ref = "int_level1_lag|int_level2_lag|waryrs_lowint|waryrs_highint"
    ci = which(grepl(ref, colnames(output)))
    output[,ci] = output[,ci] * 0
  } else if (int_level == 1){
    ref = "int_level2_lag|waryrs_highint|peaceyrs_lowint"
    ci = which(grepl(ref, colnames(output)))
    output[,ci] = output[,ci] * 0
    output[,"int_level1_lag"] = output[,"int_level1_lag"] * 0 + 1
    ref = "^int_level1_lag:|:int_level1_lag$"
    ci = which(grepl(ref, colnames(output)))
    ci2 = gsub(":int_level1_lag|:int_level1_lag:|int_level1_lag:", "", colnames(output)[ci])
    output[,ci] = output[,ci2]
  } else if (int_level == 2){
    ref = "int_level1_lag|waryrs_lowint|peaceyrs_lowint"
    ci = which(grepl(ref, colnames(output)))
    output[,ci] = output[,ci] * 0
    output[,"int_level2_lag"] = output[,"int_level2_lag"] * 0 + 1
    ref = "int_level2_lag:|:int_level2_lag"
    ci = which(grepl(ref, colnames(output)))
    ci2 = gsub(":int_level2_lag|:int_level2_lag:|int_level2_lag:", "", colnames(output)[ci])
    output[,ci] = output[,ci2]
  } else {stop("int_level?")}

  return(output)
}

fill_pp = function(df){
  df[i,1] = mean(
    apply(sim@zeta[i,1] - xbsim %*% sim@coef[i,], 1, pnorm) )
  df[i,2] = mean(
    apply(sim@zeta[i,2] - xbsim %*% sim@coef[i,], 1, pnorm) -
    apply(sim@zeta[i,1] - xbsim %*% sim@coef[i,], 1, pnorm) )
  df[i,3] = mean(
    1 - apply(sim@zeta[i,2] - xbsim %*% sim@coef[i,], 1, pnorm) )
  return(df)
}

# Function to set family_warhist DUMMY VERSION
set_fam_warhist2_dummy = function(df, value){

if(!all(c("Target_Gov_l1:fam_warhist2_dummy",
  "int_level1_lag:fam_warhist2_dummy", "fam_warhist2_dummy:int_level2_lag",
  "Target_Gov_l1:int_level1_lag:fam_warhist2_dummy",
  "Target_Gov_l1:fam_warhist2_dummy:int_level2_lag") %in% colnames(df))){stop("!!!")}

  df[, "fam_warhist2_dummy"] = value
  if(value == 1){
    df[, "Target_Gov_l1:fam_warhist2_dummy"] = df[, "Target_Gov_l1"]
    df[, "int_level1_lag:fam_warhist2_dummy"] = df[, "int_level1_lag"]
    df[, "fam_warhist2_dummy:int_level2_lag"] = df[, "int_level2_lag"]
    df[, "Target_Gov_l1:int_level1_lag:fam_warhist2_dummy"] = df[, "Target_Gov_l1:int_level1_lag"]
    df[, "Target_Gov_l1:fam_warhist2_dummy:int_level2_lag"] = df[, "Target_Gov_l1:int_level2_lag"]
  } else if (value == 0){
    df[, "Target_Gov_l1:fam_warhist2_dummy"] = 0
    df[, "int_level1_lag:fam_warhist2_dummy"] = 0
    df[, "fam_warhist2_dummy:int_level2_lag"] = 0
    df[, "Target_Gov_l1:int_level1_lag:fam_warhist2_dummy"] = 0
    df[, "Target_Gov_l1:fam_warhist2_dummy:int_level2_lag"] = 0
  } else {stop("?")}
  return(df)
}

# Function to set groupsize
set_groupsize = function(df, value){

if(!all(c("Target_Gov_l1:groupsize",
  "int_level1_lag:groupsize", "groupsize:int_level2_lag",
  "Target_Gov_l1:int_level1_lag:groupsize",
  "Target_Gov_l1:groupsize:int_level2_lag") %in% colnames(df))){stop("!!!")}

  df[, "groupsize"] = value
  df[, "Target_Gov_l1:groupsize"] = df[, "Target_Gov_l1"] * value
  df[, "int_level1_lag:groupsize"] = df[, "int_level1_lag"] * value
  df[, "groupsize:int_level2_lag"] = df[, "int_level2_lag"] * value
  df[, "Target_Gov_l1:int_level1_lag:groupsize"] = df[, "Target_Gov_l1:int_level1_lag"] * value
  df[, "Target_Gov_l1:groupsize:int_level2_lag"] = df[, "Target_Gov_l1:int_level2_lag"] * value
  return(df)
}
