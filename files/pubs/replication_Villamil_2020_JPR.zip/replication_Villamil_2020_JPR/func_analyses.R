## Functions used in the analyses code
## Francisco Villamil - April 2019
## 'Mobilizing memories: The social conditions of
## the long-term impact of victimization'


### --------------------------------------------
### Creating coefficient data frame for plotting

to_coef_df = function(model, vioname, topname, modelname){
  coefdf = as.data.frame(summary(model)$coefficients)
  coefdf = coefdf[grepl(paste0(vioname, "|", topname), rownames(coefdf)),
    c("Estimate", "Std. Error")]
  names(coefdf) = c("b", "se")
  coefdf$upr = coefdf$b + (1.96 * coefdf$se)
  coefdf$lwr = coefdf$b - (1.96 * coefdf$se)
  coefdf$var = rownames(coefdf)
  rownames(coefdf) = 1:nrow(coefdf)
  coefdf$var = gsub("factor\\(year\\)", "", coefdf$var)
  coefdf$var = gsub(vioname, "Violence", coefdf$var)
  coefdf$var = gsub(topname, "Networks", coefdf$var)
  coefdf$var = factor(coefdf$var)
  levels(coefdf$var) = gsub("(\\d{4}):(Violence):(Networks)",
    "\\2 x \\3 x \\1", levels(coefdf$var))
  levels(coefdf$var) = gsub("(\\d{4}):(Networks)", "\\2 x \\1", levels(coefdf$var))
  levels(coefdf$var) = gsub("(\\d{4}):(Violence)", "\\2 x \\1", levels(coefdf$var))
  levels(coefdf$var)[levels(coefdf$var) == "Violence:Networks"] = "Violence x Networks"
  coefdf$var = fct_relevel(coefdf$var, levels(coefdf$var)[order(levels(coefdf$var), decreasing=T)])
  coefdf$model = modelname
  return(coefdf)
}

### --------------------------------------------
### Simulation function for DiD model
### (Two functions for double- and triple-interaction model)

did_sim_3i = function(model,
  osv = 0:1, int = NULL, # Only 2x2 interactions
  osv_name = NULL, int_name = NULL,
  other_vars, # data frame!
  simdraws,
  only_estimates = FALSE,
  prov_FE = FALSE){

  # CHECKS

  # Checking inputs
  if(!is.data.frame(other_vars)){stop("other_vars != dataframe!")}
  if(is.null(int)){stop("put interaction values!")}
  if(is.null(int_name)){stop("put interaction name!")}
  if(is.null(osv_name)){stop("put osv var name!")}
  # if(all(round(int,0) == 0)){stop("all(round(int) == 0)")}
  # if(all(round(int,0) == 1)){stop("all(round(int) == 1)")}
  if(length(int) > 2){stop("length(int) > 2")}
  if(length(osv) > 2){stop("length(osv) > 2")}
  # Checking/getting coefficient order
  coefs = names(model$coefficients)
  if(!osv_name %in% coefs){stop("wrong osv name")}
  if(!int_name %in% coefs){stop("wrong int name")}
  # Checking length of osv and int
  if(length(osv) != 2 | length(int) != 2){stop("2x2 interactions?")}
  # Checking year interactions
  year_c = gsub("^factor\\(year\\)", "",
    coefs[grepl("^factor\\(year\\)....$", coefs)])
  if(is.unsorted(year_c) | "1936" %in% year_c){
    stop("Problem with year interactions")}

  # PREPARING X MATRIX

  # Basic structure of matrix
  mat = expand.grid(year = c(1936, as.integer(year_c)),
    osv = osv, int = int)
  mat = mat[order(mat$year),]
  mat = cbind(mat,
    matrix(rep(0, (length(year_c))*nrow(mat)),
      ncol = length(year_c),
      dimnames = list(NULL, year_c)) )
  for(i in year_c){mat[ mat$year == i ,i] = 1}
  # Assigning proper names
  names(mat)[names(mat) == "int"] = int_name
  names(mat)[names(mat) == "osv"] = osv_name
  names(mat)[names(mat) %in% year_c] = paste0("factor(year)",
    names(mat)[names(mat) %in% year_c])
  # Rest of the variables
  mat = cbind(mat,
    other_vars[rep(1, nrow(mat)), ])
  # Interactions
  coef_int = coefs[grepl(":", coefs)]
  for(i in coef_int){
    tmp = apply(mat[,unlist(str_split(i, ":"))], 1, prod)
    mat = cbind(mat, tmp)
    names(mat)[names(mat) == "tmp"] = i
  }
  # Intercept
  mat$Intercept = 1
  names(mat)[names(mat) == "Intercept"] = "(Intercept)"

  # If province FE > reference category
  if(prov_FE){
    coef_FE = coefs[grepl("^factor\\(prov", coefs)]
    matFE = matrix(0, ncol = length(coef_FE), nrow = nrow(mat),
      dimnames = list(NULL, coef_FE))
    mat = cbind(mat, matFE)
  }

  # CHECKING, any missing variable?
  if(!all(coefs %in% names(mat))){stop(paste0("Missing variables!: ",
      paste(coefs[!coefs %in% names(mat)], collapse = "-")))
    } else {
    intvaluenames = mat[,int_name]
    intvaluenames[mat[,int_name] == min(mat[,int_name])] = 0
    intvaluenames[mat[,int_name] == max(mat[,int_name])] = 1
    row_index = paste0("y", mat$year,
      "osv", mat[,osv_name], "int", intvaluenames)
    mat = mat[,match(coefs, names(mat))]}

  # If osv = 2 o 3
  if(any(grepl("osv2", row_index))){
    row_index = gsub("osv2", "osv1", row_index)}
  if(any(grepl("osv3", row_index))){
    row_index = gsub("osv3", "osv1", row_index)}

  # SIMULATION ESTIMATES

  # Simulation
  coefs = model$coefficients
  covmat = vcov(model)
  # Random draws of coefficients
  betadraw = mvrnorm(n = simdraws, mu = coefs, Sigma = covmat)

  # Create list of point estimates
  estimates = vector("list", length(row_index))
  names(estimates) = row_index

  for(i in 1:length(row_index)){
    name = row_index[i]
    estimates[[name]] = betadraw %*% as.numeric(mat[i,])
  }

  # OUTPUT
  return(estimates)

}

did_sim_2i = function(model,
  osv = 0:1, # Only 2x2 interactions
  osv_name = NULL,
  other_vars, # data frame!
  simdraws,
  only_estimates = FALSE,
  prov_FE = FALSE){

  # CHECKS

  # Checking inputs
  if(!is.data.frame(other_vars)){stop("other_vars != dataframe!")}
  if(is.null(osv_name)){stop("put osv var name!")}
  if(length(osv) > 2){stop("length(osv) > 2")}
  # Checking/getting coefficient order
  coefs = names(model$coefficients)
  if(!osv_name %in% coefs){stop("wrong osv name")}
  # Checking length of osv and int
  if(length(osv) != 2){stop("2x2 osv values?")}
  # Checking year interactions
  year_c = gsub("^factor\\(year\\)", "",
    coefs[grepl("^factor\\(year\\)....$", coefs)])
  if(is.unsorted(year_c) | "1936" %in% year_c){
    stop("Problem with year interactions")}

  # PREPARING X MATRIX

  # Basic structure of matrix
  mat = expand.grid(year = c(1936, as.integer(year_c)), osv = osv)
  mat = mat[order(mat$year),]
  mat = cbind(mat,
    matrix(rep(0, (length(year_c))*nrow(mat)),
      ncol = length(year_c),
      dimnames = list(NULL, year_c)) )
  for(i in year_c){mat[ mat$year == i ,i] = 1}
  # Assigning proper names
  names(mat)[names(mat) == "osv"] = osv_name
  names(mat)[names(mat) %in% year_c] = paste0("factor(year)",
    names(mat)[names(mat) %in% year_c])
  # Rest of the variables
  mat = cbind(mat,
    other_vars[rep(1, nrow(mat)), ])
  # Interactions
  coef_int = coefs[grepl(":", coefs)]
  for(i in coef_int){
    tmp = apply(mat[,unlist(str_split(i, ":"))], 1, prod)
    mat = cbind(mat, tmp)
    names(mat)[names(mat) == "tmp"] = i
  }
  # Intercept
  mat$Intercept = 1
  names(mat)[names(mat) == "Intercept"] = "(Intercept)"

  # If province FE > reference category
  if(prov_FE){
    coef_FE = coefs[grepl("^factor\\(prov", coefs)]
    matFE = matrix(0, ncol = length(coef_FE), nrow = nrow(mat),
      dimnames = list(NULL, coef_FE))
    mat = cbind(mat, matFE)
  }

  # CHECKING, any missing variable?
  if(!all(coefs %in% names(mat))){stop("Missing variables!")
    } else {
    row_index = paste0("y", mat$year, "osv", mat[,osv_name])
    mat = mat[,match(coefs, names(mat))]}

  # If osv = 2 o 3
  if(any(grepl("osv2", row_index))){
    row_index = gsub("osv2", "osv1", row_index)}
  if(any(grepl("osv3", row_index))){
    row_index = gsub("osv3", "osv1", row_index)}

  # SIMULATION ESTIMATES

  # Simulation
  coefs = model$coefficients
  covmat = vcov(model)
  # Random draws of coefficients
  betadraw = mvrnorm(n = simdraws, mu = coefs, Sigma = covmat)

  # Create list of point estimates
  estimates = vector("list", length(row_index))
  names(estimates) = row_index

  for(i in 1:length(row_index)){
    name = row_index[i]
    estimates[[name]] = betadraw %*% as.numeric(mat[i,])
  }

  # OUTPUTS

  return(estimates)

}

### --------------------------------------------
### Getting estimates from DiD models, using data from simulations
### (Two functions, for double- and triple-interaction models)

did_estimates = function(est_list, int_values){
  # baseline difference in 1936
  d1936int0 = est_list[["y1936osv1int0"]] - est_list[["y1936osv0int0"]]
  d1936int1 = est_list[["y1936osv1int1"]] - est_list[["y1936osv0int1"]]
  # DiD estimates
  d1977int0 = (est_list[["y1977osv1int0"]] - est_list[["y1977osv0int0"]]) - d1936int0
  d1979int0 = (est_list[["y1979osv1int0"]] - est_list[["y1979osv0int0"]]) - d1936int0
  d1982int0 = (est_list[["y1982osv1int0"]] - est_list[["y1982osv0int0"]]) - d1936int0
  d1986int0 = (est_list[["y1986osv1int0"]] - est_list[["y1986osv0int0"]]) - d1936int0
  d1989int0 = (est_list[["y1989osv1int0"]] - est_list[["y1989osv0int0"]]) - d1936int0
  d1993int0 = (est_list[["y1993osv1int0"]] - est_list[["y1993osv0int0"]]) - d1936int0
  d1996int0 = (est_list[["y1996osv1int0"]] - est_list[["y1996osv0int0"]]) - d1936int0
  d2000int0 = (est_list[["y2000osv1int0"]] - est_list[["y2000osv0int0"]]) - d1936int0
  d2004int0 = (est_list[["y2004osv1int0"]] - est_list[["y2004osv0int0"]]) - d1936int0
  d2008int0 = (est_list[["y2008osv1int0"]] - est_list[["y2008osv0int0"]]) - d1936int0
  d2011int0 = (est_list[["y2011osv1int0"]] - est_list[["y2011osv0int0"]]) - d1936int0
  d2015int0 = (est_list[["y2015osv1int0"]] - est_list[["y2015osv0int0"]]) - d1936int0
  d2016int0 = (est_list[["y2016osv1int0"]] - est_list[["y2016osv0int0"]]) - d1936int0
  d1977int1 = (est_list[["y1977osv1int1"]] - est_list[["y1977osv0int1"]]) - d1936int1
  d1979int1 = (est_list[["y1979osv1int1"]] - est_list[["y1979osv0int1"]]) - d1936int1
  d1982int1 = (est_list[["y1982osv1int1"]] - est_list[["y1982osv0int1"]]) - d1936int1
  d1986int1 = (est_list[["y1986osv1int1"]] - est_list[["y1986osv0int1"]]) - d1936int1
  d1989int1 = (est_list[["y1989osv1int1"]] - est_list[["y1989osv0int1"]]) - d1936int1
  d1993int1 = (est_list[["y1993osv1int1"]] - est_list[["y1993osv0int1"]]) - d1936int1
  d1996int1 = (est_list[["y1996osv1int1"]] - est_list[["y1996osv0int1"]]) - d1936int1
  d2000int1 = (est_list[["y2000osv1int1"]] - est_list[["y2000osv0int1"]]) - d1936int1
  d2004int1 = (est_list[["y2004osv1int1"]] - est_list[["y2004osv0int1"]]) - d1936int1
  d2008int1 = (est_list[["y2008osv1int1"]] - est_list[["y2008osv0int1"]]) - d1936int1
  d2011int1 = (est_list[["y2011osv1int1"]] - est_list[["y2011osv0int1"]]) - d1936int1
  d2015int1 = (est_list[["y2015osv1int1"]] - est_list[["y2015osv0int1"]]) - d1936int1
  d2016int1 = (est_list[["y2016osv1int1"]] - est_list[["y2016osv0int1"]]) - d1936int1

  ## OUTPUT
  years_did = c("1977", "1979", "1982", "1986", "1989", "1993",
    "1996", "2000", "2004", "2008", "2011", "2015", "2016")
  # Results
  results_mean = c(mean(d1977int0), mean(d1979int0), mean(d1982int0),
    mean(d1986int0), mean(d1989int0), mean(d1993int0), mean(d1996int0),
    mean(d2000int0), mean(d2004int0), mean(d2008int0), mean(d2011int0),
    mean(d2015int0), mean(d2016int0), mean(d1977int1), mean(d1979int1),
    mean(d1982int1), mean(d1986int1), mean(d1989int1),
    mean(d1993int1), mean(d1996int1), mean(d2000int1), mean(d2004int1),
    mean(d2008int1), mean(d2011int1), mean(d2015int1), mean(d2016int1))
  results_upr = c(quantile(d1977int0, 0.975), quantile(d1979int0, 0.975),
    quantile(d1982int0, 0.975), quantile(d1986int0, 0.975),
    quantile(d1989int0, 0.975), quantile(d1993int0, 0.975),
    quantile(d1996int0, 0.975), quantile(d2000int0, 0.975),
    quantile(d2004int0, 0.975), quantile(d2008int0, 0.975),
    quantile(d2011int0, 0.975), quantile(d2015int0, 0.975),
    quantile(d2016int0, 0.975), quantile(d1977int1, 0.975),
    quantile(d1979int1, 0.975), quantile(d1982int1, 0.975),
    quantile(d1986int1, 0.975), quantile(d1989int1, 0.975),
    quantile(d1993int1, 0.975), quantile(d1996int1, 0.975),
    quantile(d2000int1, 0.975), quantile(d2004int1, 0.975),
    quantile(d2008int1, 0.975), quantile(d2011int1, 0.975),
    quantile(d2015int1, 0.975), quantile(d2016int1, 0.975))
  results_lwr = c(quantile(d1977int0, 0.025), quantile(d1979int0, 0.025),
    quantile(d1982int0, 0.025), quantile(d1986int0, 0.025),
    quantile(d1989int0, 0.025), quantile(d1993int0, 0.025),
    quantile(d1996int0, 0.025), quantile(d2000int0, 0.025),
    quantile(d2004int0, 0.025), quantile(d2008int0, 0.025),
    quantile(d2011int0, 0.025), quantile(d2015int0, 0.025),
    quantile(d2016int0, 0.025), quantile(d1977int1, 0.025),
    quantile(d1979int1, 0.025), quantile(d1982int1, 0.025),
    quantile(d1986int1, 0.025), quantile(d1989int1, 0.025),
    quantile(d1993int1, 0.025), quantile(d1996int1, 0.025),
    quantile(d2000int1, 0.025), quantile(d2004int1, 0.025),
    quantile(d2008int1, 0.025), quantile(d2011int1, 0.025),
    quantile(d2015int1, 0.025), quantile(d2016int1, 0.025))
  didresults = data.frame(
    int = rep(int_values, each = 13), year = rep(years_did, 2),
    mean = results_mean, upper = results_upr, lower = results_lwr)
  return(didresults)
}

did_estimates0 = function(est_list){
  # baseline difference in 1936
  d1936 = est_list[["y1936osv1"]] - est_list[["y1936osv0"]]
  # DiD estimates
  d1977 = (est_list[["y1977osv1"]] - est_list[["y1977osv0"]]) - d1936
  d1979 = (est_list[["y1979osv1"]] - est_list[["y1979osv0"]]) - d1936
  d1982 = (est_list[["y1982osv1"]] - est_list[["y1982osv0"]]) - d1936
  d1986 = (est_list[["y1986osv1"]] - est_list[["y1986osv0"]]) - d1936
  d1989 = (est_list[["y1989osv1"]] - est_list[["y1989osv0"]]) - d1936
  d1993 = (est_list[["y1993osv1"]] - est_list[["y1993osv0"]]) - d1936
  d1996 = (est_list[["y1996osv1"]] - est_list[["y1996osv0"]]) - d1936
  d2000 = (est_list[["y2000osv1"]] - est_list[["y2000osv0"]]) - d1936
  d2004 = (est_list[["y2004osv1"]] - est_list[["y2004osv0"]]) - d1936
  d2008 = (est_list[["y2008osv1"]] - est_list[["y2008osv0"]]) - d1936
  d2011 = (est_list[["y2011osv1"]] - est_list[["y2011osv0"]]) - d1936
  d2015 = (est_list[["y2015osv1"]] - est_list[["y2015osv0"]]) - d1936
  d2016 = (est_list[["y2016osv1"]] - est_list[["y2016osv0"]]) - d1936
  # Output
  didresults = data.frame(
    year = c("1977", "1979", "1982", "1986", "1989", "1993",
      "1996", "2000", "2004", "2008", "2011", "2015", "2016"),
    mean = c(mean(d1977), mean(d1979), mean(d1982), mean(d1986),
      mean(d1989), mean(d1993), mean(d1996), mean(d2000), mean(d2004),
      mean(d2008), mean(d2011), mean(d2015), mean(d2016)),
    upper = c(quantile(d1977, 0.975), quantile(d1979, 0.975),
      quantile(d1982, 0.975), quantile(d1986, 0.975), quantile(d1989, 0.975),
      quantile(d1993, 0.975), quantile(d1996, 0.975), quantile(d2000, 0.975),
      quantile(d2004, 0.975), quantile(d2008, 0.975), quantile(d2011, 0.975),
      quantile(d2015, 0.975), quantile(d2016, 0.975)),
    lower = c(quantile(d1977, 0.025), quantile(d1979, 0.025),
      quantile(d1982, 0.025), quantile(d1986, 0.025), quantile(d1989, 0.025),
      quantile(d1993, 0.025), quantile(d1996, 0.025), quantile(d2000, 0.025),
      quantile(d2004, 0.025), quantile(d2008, 0.025), quantile(d2011, 0.025),
      quantile(d2015, 0.025), quantile(d2016, 0.025)) )
  return(didresults)
}
