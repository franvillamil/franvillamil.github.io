## Replication files for 'Civilian victimization and ethnic civil war'
## Lars-Erik Cederman, Simon Hug, Livia Schubiger and Francisco Villamil
## Journal of Conflict Resolution

## Files inside replication folder:

- dataset.csv  : data used in the analyses
- analyses.R   : script to run all the analyses in the article, including the figures and the core Latex code for the tables
- table_function.R (NOT RUN) : function used to produce the tables of the ordered probit models (it is automatically sources by analyses.R)
- oprobit_pp_functions.R (NOT RUN) : functions used in the main analyses to produce the transition probabilities (it is automatically sources by analyses.R)
