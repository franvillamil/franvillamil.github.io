## README
## Replication files for 'Mobilizing memories: The social conditions of the long-term impact of victimization'
## Francisco Villamil

# DATA AND VARIABLES

- dataset.csv : data used in the analyses
- variables.txt : explains briefly the meaning of each variable in the dataset

# R SCRIPTS

- analyses.R
  Runs the analyses in the main text, printing the plots in separate JPG files,
  together with the analyses in the appendix.
  (Note that if packages are not available, it installs them).

- func_analyses.R
  Contains the functions needed in analyses.R, and it is sourced in analyses.R,
  must be in the same folder.

# OTHER

- output.txt
  Shows the output from the R console after running analyses.R.
