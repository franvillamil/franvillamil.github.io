print_oprobit = function(model, recode = NULL){

  coef = extract(model, besides = T)@coef
  se = extract(model, besides = T)@se
  time = grepl("peaceyrs_lowint|waryrs_lowint|waryrs_highint", names(coef))
  coef = coef[!time]
  se = se[!time]
  coef = round(coef, 2)
  se = round(se, 2)

  a90 = qnorm(0.95)
  a95 = qnorm(0.975)
  a99 = qnorm(0.995)
  a999 = qnorm(0.9995)

  coef_chr = as.character(coef)
  for ( i in 1:length(coef) ){

    if (coef[i]+se[i] != 0){
    if (abs(coef[i]/se[i]) > a999) {
      coef_chr[i] = paste0(coef[i], "$^{***}$")
    } else if (abs(coef[i]/se[i]) > a99) {
      coef_chr[i] = paste0(coef[i], "$^{**}$")
    } else if (abs(coef[i]/se[i]) > a95) {
      coef_chr[i] = paste0(coef[i], "$^{*}$")
    } else if (abs(coef[i]/se[i]) > a90) {
      coef_chr[i] = paste0(coef[i], "$^{+}$")
    }
  }}

  se_chr = paste0("(", as.character(se), ")")
  se_chr[se_chr == "(0)"] = "(0.00)"
  se_chr = gsub("(\\.\\d)\\)", "\\10)", se_chr)
  coef_chr = gsub("(\\.\\d)\\)", "\\10)", coef_chr)
  coef_chr = gsub("(\\.\\d)(\\$|$)", "\\10\\2", coef_chr)


  coefnames = names(coef)

  # creating indexes
  i1 = grepl("int_level1_lag:|:int_level1_lag", coefnames)
  i2 = grepl("int_level2_lag:|:int_level2_lag", coefnames)
  i0 = which(!(i1|i2))
  int_dummies = coefnames[i0] %in% c("int_level1_lag", "int_level2_lag")
  i0 = c( i0[int_dummies], i0[!int_dummies] )

  i1 = which(i1)
  i2 = which(i2)

  names = coefnames[i0]

  # checking
  names1 = coefnames[i1]
  names2 = coefnames[i2]
  names1 = gsub("int_level1_lag:|:int_level1_lag", "", names1)
  names2 = gsub("int_level2_lag:|:int_level2_lag", "", names2)
  if(!all(names1 == names2)){stop("Problem with coef order!")}
  if(!all(names[3:length(names)] == names1)){stop("Problem with coef order!")}


  names = c(rbind(names, rep("", length(names))))
  if(!is.null(recode)){names = recode(names, recode)}

  col0 = c(rbind(coef_chr[i0], se_chr[i0]))

  coef1 = c("", "", coef_chr[i1])
  se1 = c("", "", se_chr[i1])
  col1 = c(rbind(coef1, se1))

  coef2 = c("", "", coef_chr[i2])
  se2 = c("", "", se_chr[i2])
  col2 = c(rbind(coef2, se2))
  col2 = paste0(col2, "   \\\\")

  t = cbind(names, col0, col1, col2)
  write.matrix(t, sep = "& ")

}
